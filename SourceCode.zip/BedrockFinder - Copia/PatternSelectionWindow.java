/*
 * Decompiled with CFR 0.152.
 */
package com.mike;

import com.mike.BedrockBlock;
import com.mike.BedrockFinderGUI;
import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Component;
import java.awt.Cursor;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.Font;
import java.awt.GridLayout;
import java.awt.Point;
import java.awt.Toolkit;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.awt.image.BufferedImage;
import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.List;
import javax.imageio.ImageIO;
import javax.sound.sampled.AudioInputStream;
import javax.sound.sampled.AudioSystem;
import javax.sound.sampled.Clip;
import javax.sound.sampled.FloatControl;
import javax.swing.BorderFactory;
import javax.swing.Box;
import javax.swing.BoxLayout;
import javax.swing.JButton;
import javax.swing.JCheckBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;
import javax.swing.JTextField;
import javax.swing.SwingUtilities;
import javax.swing.border.EmptyBorder;

public class PatternSelectionWindow
extends JFrame {
    private JButton[][] gridButtons;
    private List<Point> greenCubes;
    private JTextField layerField;
    private BedrockFinderGUI parentWindow;
    private BedrockBlock.BlockState[][] blockStates;
    private boolean allSelected = false;
    private JButton selectAllButton;
    private JCheckBox stopOnFirstMatchCheckBox;
    private JTextField seedField;
    private JTextField maxZField;
    private JTextField maxXField;
    private JTextField minZField;
    private JTextField minXField;
    private JTextField maxChunksField;
    private JButton confirmButton;
    private boolean isSearching = false;
    private JTextArea mediumSimilarityArea;
    private JTextArea consoleArea;
    private JScrollPane mediumSimilarityScrollPane;
    private JScrollPane consoleScrollPane;
    private JTextField commandInputField;
    private JPanel coordinatesDisplayArea;
    private JScrollPane coordinatesScrollPane;
    private Cursor normalCursor;
    private Cursor clickableCursor;
    private Cursor textCursor;
    private Clip clickSound;
    private Clip hoverSound;

    public PatternSelectionWindow(BedrockFinderGUI parent) {
        this.parentWindow = parent;
        this.greenCubes = new ArrayList<Point>();
        this.blockStates = new BedrockBlock.BlockState[16][16];
        this.gridButtons = new JButton[16][16];
        int i = 0;
        while (i < 16) {
            int j = 0;
            while (j < 16) {
                this.blockStates[i][j] = BedrockBlock.BlockState.NONE;
                ++j;
            }
            ++i;
        }
        this.initializeCustomResources();
        this.initializeWindow();
        this.createGridPanel();
        this.createSimilarityAndConsolePanel();
        this.createControlPanel();
        this.setVisible(true);
    }

    private void initializeCustomResources() {
        try {
            Toolkit toolkit = Toolkit.getDefaultToolkit();
            InputStream normalStream = this.getClass().getResourceAsStream("/Assets/Images/Mouse.png");
            if (normalStream != null) {
                BufferedImage normalImage = ImageIO.read(normalStream);
                this.normalCursor = toolkit.createCustomCursor(normalImage, new Point(0, 0), "Normal");
            } else {
                this.normalCursor = Cursor.getDefaultCursor();
            }
            InputStream clickableStream = this.getClass().getResourceAsStream("/Assets/Images/Mouse_Click.png");
            if (clickableStream != null) {
                BufferedImage clickableImage = ImageIO.read(clickableStream);
                this.clickableCursor = toolkit.createCustomCursor(clickableImage, new Point(0, 0), "Clickable");
            } else {
                this.clickableCursor = Cursor.getPredefinedCursor(12);
            }
            InputStream textStream = this.getClass().getResourceAsStream("/Assets/Images/Mouse_Text.png");
            if (textStream != null) {
                BufferedImage textImage = ImageIO.read(textStream);
                this.textCursor = toolkit.createCustomCursor(textImage, new Point(0, 0), "Text");
            } else {
                this.textCursor = Cursor.getPredefinedCursor(2);
            }
        }
        catch (IOException e) {
            System.err.println("Could not load custom cursors: " + e.getMessage());
            this.normalCursor = Cursor.getDefaultCursor();
            this.clickableCursor = Cursor.getPredefinedCursor(12);
            this.textCursor = Cursor.getPredefinedCursor(2);
        }
        try {
            InputStream hoverStream;
            InputStream clickStream = this.getClass().getResourceAsStream("/Assets/Sounds/Click.mp3");
            if (clickStream != null) {
                AudioInputStream clickAudioStream = AudioSystem.getAudioInputStream(clickStream);
                this.clickSound = AudioSystem.getClip();
                this.clickSound.open(clickAudioStream);
            }
            if ((hoverStream = this.getClass().getResourceAsStream("/Assets/Sounds/Mouse.mp3")) != null) {
                AudioInputStream hoverAudioStream = AudioSystem.getAudioInputStream(hoverStream);
                this.hoverSound = AudioSystem.getClip();
                this.hoverSound.open(hoverAudioStream);
            }
        }
        catch (Exception e) {
            System.err.println("Could not load sounds: " + e.getMessage());
        }
    }

    private void initializeWindow() {
        this.setTitle("Bedrock Pattern Selection");
        this.setDefaultCloseOperation(2);
        this.setSize(1400, 900);
        this.setLocationRelativeTo(null);
        this.setResizable(true);
        try {
            InputStream iconStream = this.getClass().getResourceAsStream("/Assets/Images/App-Icon.png");
            if (iconStream != null) {
                BufferedImage iconImage = ImageIO.read(iconStream);
                this.setIconImage(iconImage);
            }
        }
        catch (IOException e) {
            System.err.println("Could not load application icon: " + e.getMessage());
        }
        this.getContentPane().setBackground(Color.BLACK);
        this.setLayout(new BorderLayout());
        this.setCursor(this.normalCursor);
        this.addWindowListener(new WindowAdapter(){

            @Override
            public void windowClosing(WindowEvent windowEvent) {
                PatternSelectionWindow.this.dispose();
            }
        });
    }

    private void createGridPanel() {
        JPanel gridPanel = new JPanel(new GridLayout(16, 16, 1, 1));
        gridPanel.setBackground(Color.BLACK);
        gridPanel.setBorder(new EmptyBorder(20, 20, 10, 20));
        int row = 0;
        while (row < 16) {
            int col = 0;
            while (col < 16) {
                final int finalRow = row;
                final int finalCol = col;
                final JButton button = new JButton();
                button.setPreferredSize(new Dimension(25, 25));
                button.setBackground(Color.LIGHT_GRAY);
                button.setBorder(BorderFactory.createLineBorder(Color.GRAY, 1));
                button.setFocusPainted(false);
                button.addMouseListener(new MouseAdapter(){

                    @Override
                    public void mouseClicked(MouseEvent e) {
                        if (e.getClickCount() == 1) {
                            PatternSelectionWindow.this.playClickSound();
                            if (SwingUtilities.isLeftMouseButton(e)) {
                                PatternSelectionWindow.this.cycleBlockState(finalRow, finalCol);
                            } else if (SwingUtilities.isRightMouseButton(e)) {
                                PatternSelectionWindow.this.resetBlockState(finalRow, finalCol);
                            }
                        }
                    }

                    @Override
                    public void mouseEntered(MouseEvent e) {
                        button.setCursor(PatternSelectionWindow.this.clickableCursor);
                        PatternSelectionWindow.this.playHoverSound();
                    }

                    @Override
                    public void mouseExited(MouseEvent e) {
                        button.setCursor(PatternSelectionWindow.this.normalCursor);
                    }
                });
                this.gridButtons[row][col] = button;
                gridPanel.add(button);
                ++col;
            }
            ++row;
        }
        this.add((Component)gridPanel, "Center");
    }

    private void createSimilarityAndConsolePanel() {
        JPanel mainPanel = new JPanel(new BorderLayout());
        mainPanel.setBackground(Color.BLACK);
        JPanel similarityPanel = new JPanel(new BorderLayout());
        similarityPanel.setBackground(Color.BLACK);
        similarityPanel.setBorder(new EmptyBorder(5, 10, 5, 10));
        JLabel similarityLabel = new JLabel("Medium Similarity Matches (85-95%):");
        similarityLabel.setForeground(Color.WHITE);
        similarityLabel.setFont(new Font("Arial", 1, 12));
        similarityPanel.add((Component)similarityLabel, "North");
        this.mediumSimilarityArea = new JTextArea(3, 50);
        this.mediumSimilarityArea.setBackground(Color.DARK_GRAY);
        this.mediumSimilarityArea.setForeground(Color.WHITE);
        this.mediumSimilarityArea.setFont(new Font("Consolas", 0, 11));
        this.mediumSimilarityArea.setEditable(false);
        this.mediumSimilarityArea.setText("No medium similarity matches found yet...");
        this.mediumSimilarityScrollPane = new JScrollPane(this.mediumSimilarityArea);
        this.mediumSimilarityScrollPane.setVerticalScrollBarPolicy(20);
        this.mediumSimilarityScrollPane.setHorizontalScrollBarPolicy(30);
        similarityPanel.add((Component)this.mediumSimilarityScrollPane, "Center");
        JPanel rightPanel = new JPanel(new BorderLayout());
        rightPanel.setBackground(Color.BLACK);
        JPanel consolePanel = new JPanel(new BorderLayout());
        consolePanel.setBackground(Color.BLACK);
        consolePanel.setBorder(new EmptyBorder(10, 10, 10, 5));
        consolePanel.setPreferredSize(new Dimension(350, 250));
        JLabel consoleLabel = new JLabel("Console:");
        consoleLabel.setForeground(Color.WHITE);
        consoleLabel.setFont(new Font("Arial", 1, 12));
        consolePanel.add((Component)consoleLabel, "North");
        this.consoleArea = new JTextArea(20, 30);
        this.consoleArea.setBackground(Color.BLACK);
        this.consoleArea.setForeground(Color.GREEN);
        this.consoleArea.setFont(new Font("Consolas", 0, 10));
        this.consoleArea.setEditable(false);
        this.consoleArea.setText("Console initialized...\nReady for pattern search.\n");
        this.consoleScrollPane = new JScrollPane(this.consoleArea);
        this.consoleScrollPane.setVerticalScrollBarPolicy(20);
        this.consoleScrollPane.setHorizontalScrollBarPolicy(30);
        consolePanel.add((Component)this.consoleScrollPane, "Center");
        JPanel commandPanel = new JPanel(new BorderLayout());
        commandPanel.setBackground(Color.BLACK);
        commandPanel.setBorder(new EmptyBorder(5, 0, 0, 0));
        JLabel commandLabel = new JLabel("Command: ");
        commandLabel.setForeground(Color.WHITE);
        commandLabel.setFont(new Font("Arial", 0, 10));
        commandPanel.add((Component)commandLabel, "West");
        this.commandInputField = new JTextField();
        this.commandInputField.setBackground(Color.DARK_GRAY);
        this.commandInputField.setForeground(Color.WHITE);
        this.commandInputField.setFont(new Font("Consolas", 0, 10));
        this.commandInputField.setCaretColor(Color.WHITE);
        this.commandInputField.addActionListener(e -> this.processCommand(this.commandInputField.getText()));
        this.addTextFieldEffects(this.commandInputField);
        commandPanel.add((Component)this.commandInputField, "Center");
        consolePanel.add((Component)commandPanel, "South");
        JPanel helpPanel = new JPanel(new BorderLayout());
        helpPanel.setBackground(Color.BLACK);
        helpPanel.setBorder(new EmptyBorder(10, 5, 10, 10));
        helpPanel.setPreferredSize(new Dimension(300, 250));
        JLabel helpLabel = new JLabel("\ud83e\udea8 Bedrock Finder Help");
        helpLabel.setForeground(Color.WHITE);
        helpLabel.setFont(new Font("Arial", 1, 12));
        helpPanel.add((Component)helpLabel, "North");
        JTextArea helpArea = new JTextArea();
        helpArea.setBackground(Color.DARK_GRAY);
        helpArea.setForeground(Color.WHITE);
        helpArea.setFont(new Font("Consolas", 0, 10));
        helpArea.setEditable(false);
        helpArea.setLineWrap(true);
        helpArea.setWrapStyleWord(true);
        helpArea.setText("1. How to Find Bases with Bedrock\n\nUse the start command in the command line.\n\nEnter the bedrock pattern on the 16\u00d716 grid\n\nIn the textbox, choose a scan level from 0 to 4:\n\n0 \u2192 scan all bedrock layers\n1 \u2192 scan Y = -61\n2 \u2192 scan Y = -62\n3 \u2192 scan Y = -63\n4 \u2192 scan Y = -64\n\nPress Continue, then enter the world seed and the maximum Z/X and the minimum Z/X coordinates.\n\nPress \"Confirm\" and then wait until the application finds a matching bedrock pattern\n\n\n2. Stop Command\n\nUse stop to cancel the current scanning process.\n\n3. Clear command\n\nClear the console\n\n4. Info command\n\nShows how the bedrock pattern looks like where the app is looking at\n\n5. Reset command\n\nresets the atual coords grid");
        JScrollPane helpScrollPane = new JScrollPane(helpArea);
        helpScrollPane.setVerticalScrollBarPolicy(20);
        helpScrollPane.setHorizontalScrollBarPolicy(30);
        helpPanel.add((Component)helpScrollPane, "Center");
        rightPanel.add((Component)consolePanel, "West");
        rightPanel.add((Component)helpPanel, "East");
        mainPanel.add((Component)similarityPanel, "Center");
        mainPanel.add((Component)rightPanel, "East");
        this.add((Component)mainPanel, "South");
    }

    private void createControlPanel() {
        JPanel controlPanel = new JPanel();
        controlPanel.setLayout(new BoxLayout(controlPanel, 1));
        controlPanel.setBackground(Color.BLACK);
        controlPanel.setBorder(new EmptyBorder(10, 20, 20, 20));
        this.createCoordinatesDisplayArea();
        controlPanel.add(this.coordinatesScrollPane);
        controlPanel.add(Box.createVerticalStrut(15));
        JLabel layerLabel = new JLabel("Bedrock layer to look at:");
        layerLabel.setForeground(Color.WHITE);
        layerLabel.setFont(new Font("Arial", 1, 12));
        controlPanel.add(layerLabel);
        controlPanel.add(Box.createVerticalStrut(5));
        this.layerField = new JTextField("0");
        this.layerField.setPreferredSize(new Dimension(100, 25));
        this.layerField.setMaximumSize(new Dimension(100, 25));
        this.layerField.setAlignmentX(0.0f);
        this.layerField.setBackground(Color.DARK_GRAY);
        this.layerField.setForeground(Color.WHITE);
        this.layerField.setCaretColor(Color.WHITE);
        this.addTextFieldEffects(this.layerField);
        controlPanel.add(this.layerField);
        controlPanel.add(Box.createVerticalStrut(5));
        JLabel tipLabel = new JLabel("TIP: 0=all, 1=Y-60, 2=Y-61, 3=Y-62, 4=Y-63");
        tipLabel.setForeground(Color.LIGHT_GRAY);
        tipLabel.setFont(new Font("Arial", 2, 10));
        controlPanel.add(tipLabel);
        controlPanel.add(Box.createVerticalStrut(15));
        this.stopOnFirstMatchCheckBox = new JCheckBox("Stop on perfect match");
        this.stopOnFirstMatchCheckBox.setForeground(Color.WHITE);
        this.stopOnFirstMatchCheckBox.setBackground(Color.BLACK);
        this.stopOnFirstMatchCheckBox.setFont(new Font("Arial", 1, 12));
        this.stopOnFirstMatchCheckBox.setAlignmentX(0.0f);
        this.stopOnFirstMatchCheckBox.setSelected(false);
        controlPanel.add(this.stopOnFirstMatchCheckBox);
        controlPanel.add(Box.createVerticalStrut(15));
        JLabel maxChunksLabel = new JLabel("Max chunks to scan:");
        maxChunksLabel.setForeground(Color.WHITE);
        maxChunksLabel.setFont(new Font("Arial", 1, 12));
        controlPanel.add(maxChunksLabel);
        controlPanel.add(Box.createVerticalStrut(5));
        this.maxChunksField = new JTextField("10000");
        this.maxChunksField.setPreferredSize(new Dimension(100, 25));
        this.maxChunksField.setMaximumSize(new Dimension(100, 25));
        this.maxChunksField.setAlignmentX(0.0f);
        this.maxChunksField.setBackground(Color.DARK_GRAY);
        this.maxChunksField.setForeground(Color.WHITE);
        this.maxChunksField.setCaretColor(Color.WHITE);
        this.addTextFieldEffects(this.maxChunksField);
        controlPanel.add(this.maxChunksField);
        controlPanel.add(Box.createVerticalStrut(15));
        JLabel seedLabel = new JLabel("Seed:");
        seedLabel.setForeground(Color.WHITE);
        seedLabel.setFont(new Font("Arial", 1, 12));
        controlPanel.add(seedLabel);
        controlPanel.add(Box.createVerticalStrut(5));
        this.seedField = new JTextField();
        this.seedField.setPreferredSize(new Dimension(200, 25));
        this.seedField.setMaximumSize(new Dimension(200, 25));
        this.seedField.setAlignmentX(0.0f);
        this.seedField.setBackground(Color.DARK_GRAY);
        this.seedField.setForeground(Color.WHITE);
        this.seedField.setCaretColor(Color.WHITE);
        this.addTextFieldEffects(this.seedField);
        controlPanel.add(this.seedField);
        controlPanel.add(Box.createVerticalStrut(15));
        JPanel coordPanel = new JPanel();
        coordPanel.setLayout(new BoxLayout(coordPanel, 1));
        coordPanel.setBackground(Color.BLACK);
        coordPanel.setAlignmentX(0.0f);
        JPanel coordGridPanel = new JPanel(new GridLayout(2, 2, 15, 10));
        coordGridPanel.setBackground(Color.BLACK);
        coordGridPanel.setAlignmentX(0.0f);
        JPanel maxZPanel = new JPanel();
        maxZPanel.setLayout(new BoxLayout(maxZPanel, 1));
        maxZPanel.setBackground(Color.BLACK);
        JLabel maxZLabel = new JLabel("Maximum Z coordinates:");
        maxZLabel.setForeground(Color.WHITE);
        maxZLabel.setFont(new Font("Arial", 1, 12));
        maxZLabel.setAlignmentX(0.0f);
        maxZPanel.add(maxZLabel);
        maxZPanel.add(Box.createVerticalStrut(5));
        this.maxZField = new JTextField("999999999");
        this.maxZField.setPreferredSize(new Dimension(120, 25));
        this.maxZField.setMaximumSize(new Dimension(120, 25));
        this.maxZField.setBackground(Color.DARK_GRAY);
        this.maxZField.setForeground(Color.WHITE);
        this.maxZField.setCaretColor(Color.WHITE);
        this.maxZField.setAlignmentX(0.0f);
        this.addTextFieldEffects(this.maxZField);
        maxZPanel.add(this.maxZField);
        JPanel maxXPanel = new JPanel();
        maxXPanel.setLayout(new BoxLayout(maxXPanel, 1));
        maxXPanel.setBackground(Color.BLACK);
        JLabel maxXLabel = new JLabel("Maximum X coordinates:");
        maxXLabel.setForeground(Color.WHITE);
        maxXLabel.setFont(new Font("Arial", 1, 12));
        maxXLabel.setAlignmentX(0.0f);
        maxXPanel.add(maxXLabel);
        maxXPanel.add(Box.createVerticalStrut(5));
        this.maxXField = new JTextField("999999999");
        this.maxXField.setPreferredSize(new Dimension(120, 25));
        this.maxXField.setMaximumSize(new Dimension(120, 25));
        this.maxXField.setBackground(Color.DARK_GRAY);
        this.maxXField.setForeground(Color.WHITE);
        this.maxXField.setCaretColor(Color.WHITE);
        this.maxXField.setAlignmentX(0.0f);
        this.addTextFieldEffects(this.maxXField);
        maxXPanel.add(this.maxXField);
        JPanel minZPanel = new JPanel();
        minZPanel.setLayout(new BoxLayout(minZPanel, 1));
        minZPanel.setBackground(Color.BLACK);
        JLabel minZLabel = new JLabel("Minimum Z coordinates:");
        minZLabel.setForeground(Color.WHITE);
        minZLabel.setFont(new Font("Arial", 1, 12));
        minZLabel.setAlignmentX(0.0f);
        minZPanel.add(minZLabel);
        minZPanel.add(Box.createVerticalStrut(5));
        this.minZField = new JTextField("-999999999");
        this.minZField.setPreferredSize(new Dimension(120, 25));
        this.minZField.setMaximumSize(new Dimension(120, 25));
        this.minZField.setBackground(Color.DARK_GRAY);
        this.minZField.setForeground(Color.WHITE);
        this.minZField.setCaretColor(Color.WHITE);
        this.minZField.setAlignmentX(0.0f);
        this.addTextFieldEffects(this.minZField);
        minZPanel.add(this.minZField);
        JPanel minXPanel = new JPanel();
        minXPanel.setLayout(new BoxLayout(minXPanel, 1));
        minXPanel.setBackground(Color.BLACK);
        JLabel minXLabel = new JLabel("Minimum X coordinates:");
        minXLabel.setForeground(Color.WHITE);
        minXLabel.setFont(new Font("Arial", 1, 12));
        minXLabel.setAlignmentX(0.0f);
        minXPanel.add(minXLabel);
        minXPanel.add(Box.createVerticalStrut(5));
        this.minXField = new JTextField("-999999999");
        this.minXField.setPreferredSize(new Dimension(120, 25));
        this.minXField.setMaximumSize(new Dimension(120, 25));
        this.minXField.setBackground(Color.DARK_GRAY);
        this.minXField.setForeground(Color.WHITE);
        this.minXField.setCaretColor(Color.WHITE);
        this.minXField.setAlignmentX(0.0f);
        this.addTextFieldEffects(this.minXField);
        minXPanel.add(this.minXField);
        coordGridPanel.add(maxZPanel);
        coordGridPanel.add(maxXPanel);
        coordGridPanel.add(minZPanel);
        coordGridPanel.add(minXPanel);
        coordPanel.add(coordGridPanel);
        controlPanel.add(coordPanel);
        controlPanel.add(Box.createVerticalStrut(20));
        this.selectAllButton = new JButton("Select All");
        this.selectAllButton.setPreferredSize(new Dimension(120, 30));
        this.selectAllButton.setBackground(Color.GREEN);
        this.selectAllButton.setForeground(Color.WHITE);
        this.selectAllButton.setAlignmentX(0.0f);
        this.selectAllButton.addActionListener(new ActionListener(){

            @Override
            public void actionPerformed(ActionEvent e) {
                PatternSelectionWindow.this.toggleSelectAll();
            }
        });
        this.addButtonEffects(this.selectAllButton);
        controlPanel.add(this.selectAllButton);
        controlPanel.add(Box.createVerticalStrut(10));
        JPanel buttonPanel = new JPanel(new FlowLayout());
        buttonPanel.setBackground(Color.BLACK);
        this.confirmButton = new JButton("Confirm");
        this.confirmButton.setPreferredSize(new Dimension(80, 30));
        this.confirmButton.setBackground(Color.DARK_GRAY);
        this.confirmButton.setForeground(Color.WHITE);
        this.confirmButton.addActionListener(new ActionListener(){

            @Override
            public void actionPerformed(ActionEvent e) {
                PatternSelectionWindow.this.handleConfirmButtonClick();
            }
        });
        this.addButtonEffects(this.confirmButton);
        JButton cancelButton = new JButton("Cancel");
        cancelButton.setPreferredSize(new Dimension(80, 30));
        cancelButton.setBackground(Color.DARK_GRAY);
        cancelButton.setForeground(Color.WHITE);
        cancelButton.addActionListener(new ActionListener(){

            @Override
            public void actionPerformed(ActionEvent e) {
                PatternSelectionWindow.this.dispose();
            }
        });
        this.addButtonEffects(cancelButton);
        buttonPanel.add(this.confirmButton);
        buttonPanel.add(cancelButton);
        controlPanel.add(buttonPanel);
        this.add((Component)controlPanel, "West");
    }

    private void createCoordinatesDisplayArea() {
        this.coordinatesDisplayArea = new JPanel();
        this.coordinatesDisplayArea.setLayout(new BoxLayout(this.coordinatesDisplayArea, 1));
        this.coordinatesDisplayArea.setBackground(Color.BLACK);
        this.coordinatesDisplayArea.setBorder(BorderFactory.createTitledBorder(BorderFactory.createLineBorder(Color.GRAY), "Selected Coordinates", 0, 0, new Font("Arial", 1, 12), Color.WHITE));
        this.coordinatesScrollPane = new JScrollPane(this.coordinatesDisplayArea);
        this.coordinatesScrollPane.setPreferredSize(new Dimension(400, 120));
        this.coordinatesScrollPane.setMaximumSize(new Dimension(400, 120));
        this.coordinatesScrollPane.setBackground(Color.BLACK);
        this.coordinatesScrollPane.getViewport().setBackground(Color.BLACK);
        this.coordinatesScrollPane.setBorder(BorderFactory.createLineBorder(Color.GRAY));
        this.coordinatesScrollPane.setAlignmentX(0.0f);
        this.updateCoordinatesDisplayArea();
    }

    private void updateCoordinatesDisplayArea() {
        this.coordinatesDisplayArea.removeAll();
        this.addCoordinateSection("Green (bedrock):", this.greenCubes, new Color(100, 255, 100));
        if (this.greenCubes.isEmpty()) {
            JLabel emptyLabel = new JLabel("No coordinates selected");
            emptyLabel.setForeground(Color.LIGHT_GRAY);
            emptyLabel.setFont(new Font("Arial", 2, 12));
            emptyLabel.setAlignmentX(0.0f);
            this.coordinatesDisplayArea.add(emptyLabel);
        }
        this.coordinatesDisplayArea.revalidate();
        this.coordinatesDisplayArea.repaint();
    }

    private void addCoordinateSection(String title, List<Point> coordinates, Color color) {
        if (coordinates.isEmpty()) {
            return;
        }
        JLabel titleLabel = new JLabel(title);
        titleLabel.setForeground(Color.WHITE);
        titleLabel.setFont(new Font("Arial", 1, 11));
        titleLabel.setAlignmentX(0.0f);
        this.coordinatesDisplayArea.add(titleLabel);
        JPanel coordsPanel = new JPanel();
        coordsPanel.setLayout(new BoxLayout(coordsPanel, 1));
        coordsPanel.setBackground(Color.BLACK);
        coordsPanel.setAlignmentX(0.0f);
        int i = 0;
        while (i < coordinates.size()) {
            JPanel rowPanel = new JPanel(new FlowLayout(0, 2, 0));
            rowPanel.setBackground(Color.BLACK);
            rowPanel.setAlignmentX(0.0f);
            int j = i;
            while (j < Math.min(i + 5, coordinates.size())) {
                Point p = coordinates.get(j);
                JLabel coordLabel = new JLabel("(" + p.x + "," + p.y + ")");
                coordLabel.setForeground(color);
                coordLabel.setFont(new Font("Arial", 0, 10));
                coordLabel.setBorder(BorderFactory.createEmptyBorder(1, 3, 1, 3));
                rowPanel.add(coordLabel);
                ++j;
            }
            coordsPanel.add(rowPanel);
            i += 5;
        }
        this.coordinatesDisplayArea.add(coordsPanel);
        this.coordinatesDisplayArea.add(Box.createVerticalStrut(5));
    }

    private void cycleBlockState(int row, int col) {
        int relativeX = col - 8;
        int relativeZ = 8 - row;
        Point point = new Point(relativeX, relativeZ);
        this.greenCubes.removeIf(p -> p.x == relativeX && p.y == relativeZ);
        BedrockBlock.BlockState currentState = this.blockStates[row][col];
        if (currentState == BedrockBlock.BlockState.NONE) {
            this.blockStates[row][col] = BedrockBlock.BlockState.SUSPECT;
            this.gridButtons[row][col].setBackground(Color.GREEN);
            this.greenCubes.add(point);
        } else {
            this.blockStates[row][col] = BedrockBlock.BlockState.NONE;
            this.gridButtons[row][col].setBackground(Color.LIGHT_GRAY);
        }
        this.updateCoordinatesDisplay();
    }

    private void resetBlockState(int row, int col) {
        int relativeX = col - 8;
        int relativeZ = 8 - row;
        Point point = new Point(relativeX, relativeZ);
        this.greenCubes.removeIf(p -> p.x == relativeX && p.y == relativeZ);
        this.blockStates[row][col] = BedrockBlock.BlockState.NONE;
        this.gridButtons[row][col].setBackground(Color.LIGHT_GRAY);
        this.updateCoordinatesDisplay();
    }

    private void updateCoordinatesDisplay() {
        this.updateCoordinatesDisplayArea();
    }

    private void toggleSelectAll() {
        if (!this.allSelected) {
            int row = 0;
            while (row < 16) {
                int col = 0;
                while (col < 16) {
                    int relativeX = col - 8;
                    int relativeZ = 8 - row;
                    Point point = new Point(relativeX, relativeZ);
                    this.greenCubes.removeIf(p -> p.x == relativeX && p.y == relativeZ);
                    this.blockStates[row][col] = BedrockBlock.BlockState.SUSPECT;
                    this.gridButtons[row][col].setBackground(Color.GREEN);
                    this.greenCubes.add(point);
                    ++col;
                }
                ++row;
            }
            this.allSelected = true;
            this.selectAllButton.setText("Deselect All");
            this.selectAllButton.setBackground(Color.RED);
        } else {
            int row = 0;
            while (row < 16) {
                int col = 0;
                while (col < 16) {
                    int relativeX = col - 8;
                    int relativeZ = 8 - row;
                    this.greenCubes.removeIf(p -> p.x == relativeX && p.y == relativeZ);
                    this.blockStates[row][col] = BedrockBlock.BlockState.NONE;
                    this.gridButtons[row][col].setBackground(Color.LIGHT_GRAY);
                    ++col;
                }
                ++row;
            }
            this.allSelected = false;
            this.selectAllButton.setText("Select All");
            this.selectAllButton.setBackground(Color.GREEN);
        }
        this.updateCoordinatesDisplay();
    }

    private void confirmSelection() {
        if (this.greenCubes.isEmpty()) {
            JOptionPane.showMessageDialog(this, "Please select at least one bedrock cube (green)!", "No Selection", 2);
            return;
        }
        try {
            int maxChunks;
            int minX;
            int minZ;
            int maxX;
            int maxZ;
            long seed;
            int layer = Integer.parseInt(this.layerField.getText());
            if (layer < 0 || layer > 4) {
                JOptionPane.showMessageDialog(this, "Layer value should be between 0 and 4!", "Invalid Layer", 0);
                return;
            }
            String seedInput = this.seedField.getText().trim();
            if (seedInput.isEmpty()) {
                JOptionPane.showMessageDialog(this, "Please enter a seed!", "Missing Seed", 2);
                return;
            }
            try {
                seed = Long.parseLong(seedInput);
            }
            catch (NumberFormatException e) {
                JOptionPane.showMessageDialog(this, "Please enter a valid seed number!", "Invalid Seed", 0);
                return;
            }
            try {
                maxZ = Integer.parseInt(this.maxZField.getText().trim());
                maxX = Integer.parseInt(this.maxXField.getText().trim());
                minZ = Integer.parseInt(this.minZField.getText().trim());
                minX = Integer.parseInt(this.minXField.getText().trim());
                maxChunks = Integer.parseInt(this.maxChunksField.getText().trim());
            }
            catch (NumberFormatException e) {
                JOptionPane.showMessageDialog(this, "Please enter valid numbers for all coordinate fields!", "Invalid Coordinates", 0);
                return;
            }
            if (maxChunks <= 0) {
                JOptionPane.showMessageDialog(this, "Max chunks to scan must be greater than 0!", "Invalid Max Chunks", 0);
                return;
            }
            if (maxZ <= minZ || maxX <= minX) {
                JOptionPane.showMessageDialog(this, "Maximum coordinates must be greater than minimum coordinates!", "Invalid Range", 0);
                return;
            }
            boolean stopOnFirstMatch = this.stopOnFirstMatchCheckBox.isSelected();
            ArrayList<BedrockBlock> pattern = new ArrayList<BedrockBlock>();
            for (Point p : this.greenCubes) {
                pattern.add(new BedrockBlock(p.x, 0, p.y, BedrockBlock.BlockState.SUSPECT));
            }
            this.parentWindow.startSearchFromGUI(seed, pattern, layer, stopOnFirstMatch, minX, maxX, minZ, maxZ, maxChunks, this);
        }
        catch (NumberFormatException e) {
            JOptionPane.showMessageDialog(this, "Please enter valid numbers for all fields!", "Invalid Input", 0);
        }
    }

    private void handleConfirmButtonClick() {
        if (this.isSearching) {
            this.parentWindow.stopSearch();
            this.setSearchState(false);
        } else {
            this.setSearchState(true);
            this.confirmSelection();
        }
    }

    public void setSearchState(boolean searching) {
        this.isSearching = searching;
        SwingUtilities.invokeLater(() -> {
            if (searching) {
                this.confirmButton.setText("Cancel Operation");
                this.confirmButton.setBackground(Color.RED);
                this.confirmButton.setForeground(Color.WHITE);
            } else {
                this.confirmButton.setText("Confirm");
                this.confirmButton.setBackground(Color.DARK_GRAY);
                this.confirmButton.setForeground(Color.WHITE);
            }
        });
    }

    public List<Point> getGreenCubes() {
        return this.greenCubes;
    }

    public int getSelectedLayer() {
        try {
            return Integer.parseInt(this.layerField.getText());
        }
        catch (NumberFormatException e) {
            return 0;
        }
    }

    public void updateMediumSimilarityMatches(List<BedrockFinderGUI.SimilarityMatch> matches) {
        SwingUtilities.invokeLater(() -> {
            if (matches.isEmpty()) {
                this.mediumSimilarityArea.setText("No medium similarity matches found yet...");
            } else {
                StringBuilder sb = new StringBuilder();
                sb.append("Found ").append(matches.size()).append(" medium similarity matches:\n\n");
                int i = 0;
                while (i < matches.size()) {
                    BedrockFinderGUI.SimilarityMatch match = (BedrockFinderGUI.SimilarityMatch)matches.get(i);
                    sb.append(String.format("%d. X:%d Z:%d Y:%d - %.1f%%\n", i + 1, match.centerX, match.centerZ, match.y, match.similarity * 100.0));
                    ++i;
                }
                this.mediumSimilarityArea.setText(sb.toString());
                this.mediumSimilarityArea.setCaretPosition(0);
            }
        });
    }

    public void addConsoleMessage(String message) {
        SwingUtilities.invokeLater(() -> {
            this.consoleArea.append(message + "\n");
            this.consoleArea.setCaretPosition(this.consoleArea.getDocument().getLength());
        });
    }

    public void clearConsole() {
        SwingUtilities.invokeLater(() -> this.consoleArea.setText("Console cleared...\n"));
    }

    private void processCommand(String command) {
        String cmd;
        if (command == null || command.trim().isEmpty()) {
            return;
        }
        command = command.trim();
        this.addConsoleMessage("> " + command);
        this.commandInputField.setText("");
        String[] parts = command.split("\\s+");
        switch (cmd = parts[0].toLowerCase()) {
            case "start": {
                this.addConsoleMessage("Starting pattern search...");
                this.confirmSelection();
                break;
            }
            case "stop": {
                this.addConsoleMessage("Stopping search...");
                if (this.parentWindow == null) break;
                this.parentWindow.processConfirmation("stop");
                break;
            }
            case "clear": {
                this.clearConsole();
                break;
            }
            case "info": {
                this.showPatternInfo();
                break;
            }
            case "reset": {
                this.resetAllCoordinates();
                break;
            }
            default: {
                this.addConsoleMessage("Unknown command: " + cmd + ". Check the help panel for available commands.");
            }
        }
    }

    private void showPatternInfo() {
        int greenCount = this.greenCubes.size();
        this.addConsoleMessage("Pattern Information:");
        this.addConsoleMessage("  Green blocks (bedrock): " + greenCount);
        this.addConsoleMessage("  Total pattern blocks: " + greenCount);
        this.addConsoleMessage("  Selected layer: " + this.getSelectedLayer());
    }

    private void showCoordinatesInfo() {
        try {
            int minX = Integer.parseInt(this.minXField.getText());
            int maxX = Integer.parseInt(this.maxXField.getText());
            int minZ = Integer.parseInt(this.minZField.getText());
            int maxZ = Integer.parseInt(this.maxZField.getText());
            this.addConsoleMessage("Search Coordinates:");
            this.addConsoleMessage("  X range: " + minX + " to " + maxX);
            this.addConsoleMessage("  Z range: " + minZ + " to " + maxZ);
            this.addConsoleMessage("  Search area: " + (maxX - minX + 1) * (maxZ - minZ + 1) + " chunks");
        }
        catch (NumberFormatException e) {
            this.addConsoleMessage("Invalid coordinates format. Please check your input fields.");
        }
    }

    private void addCoordinateFromCommand(String coordStr, String colorStr) {
        try {
            String[] coords = coordStr.split(",");
            if (coords.length != 2) {
                this.addConsoleMessage("Invalid coordinate format. Use: x,z (e.g., 5,3)");
                return;
            }
            int x = Integer.parseInt(coords[0].trim());
            int z = Integer.parseInt(coords[1].trim());
            if (x < 0 || x >= 16 || z < 0 || z >= 16) {
                this.addConsoleMessage("Coordinates must be between 0-15. Got: " + x + "," + z);
                return;
            }
            Point point = new Point(x, z);
            String color = colorStr.toLowerCase().trim();
            this.greenCubes.remove(point);
            switch (color) {
                case "green": {
                    this.greenCubes.add(point);
                    this.blockStates[z][x] = BedrockBlock.BlockState.SUSPECT;
                    this.addConsoleMessage("Added green coordinate: " + x + "," + z);
                    break;
                }
                default: {
                    this.addConsoleMessage("Invalid color. Use: green");
                    return;
                }
            }
            this.updateButtonColor(z, x);
            this.updateCoordinatesDisplayArea();
        }
        catch (NumberFormatException e) {
            this.addConsoleMessage("Invalid coordinate format. Use numbers only (e.g., 5,3)");
        }
    }

    private void removeCoordinateFromCommand(String coordStr) {
        try {
            String[] coords = coordStr.split(",");
            if (coords.length != 2) {
                this.addConsoleMessage("Invalid coordinate format. Use: x,z (e.g., 5,3)");
                return;
            }
            int x = Integer.parseInt(coords[0].trim());
            int z = Integer.parseInt(coords[1].trim());
            if (x < 0 || x >= 16 || z < 0 || z >= 16) {
                this.addConsoleMessage("Coordinates must be between 0-15. Got: " + x + "," + z);
                return;
            }
            Point point = new Point(x, z);
            boolean removed = false;
            if (this.greenCubes.remove(point)) {
                this.addConsoleMessage("Removed green coordinate: " + x + "," + z);
                removed = true;
            }
            if (!removed) {
                this.addConsoleMessage("No coordinate found at: " + x + "," + z);
                return;
            }
            this.blockStates[z][x] = BedrockBlock.BlockState.NONE;
            this.updateButtonColor(z, x);
            this.updateCoordinatesDisplayArea();
        }
        catch (NumberFormatException e) {
            this.addConsoleMessage("Invalid coordinate format. Use numbers only (e.g., 5,3)");
        }
    }

    private void resetAllCoordinates() {
        int totalRemoved = this.greenCubes.size();
        this.greenCubes.clear();
        int i = 0;
        while (i < 16) {
            int j = 0;
            while (j < 16) {
                this.blockStates[i][j] = BedrockBlock.BlockState.NONE;
                this.updateButtonColor(i, j);
                ++j;
            }
            ++i;
        }
        this.updateCoordinatesDisplayArea();
        this.addConsoleMessage("Reset complete. Removed " + totalRemoved + " coordinates.");
    }

    private void updateButtonColor(int row, int col) {
        JButton button = this.gridButtons[row][col];
        switch (this.blockStates[row][col]) {
            case NONE: {
                button.setBackground(Color.LIGHT_GRAY);
                break;
            }
            case SUSPECT: {
                button.setBackground(Color.GREEN);
            }
        }
    }

    private void playClickSound() {
        if (this.clickSound != null) {
            try {
                if (this.clickSound.isControlSupported(FloatControl.Type.MASTER_GAIN)) {
                    FloatControl gainControl = (FloatControl)this.clickSound.getControl(FloatControl.Type.MASTER_GAIN);
                    gainControl.setValue(gainControl.getMaximum());
                }
                this.clickSound.setFramePosition(0);
                this.clickSound.start();
            }
            catch (Exception exception) {
                // empty catch block
            }
        }
    }

    private void playHoverSound() {
        if (this.hoverSound != null) {
            try {
                if (this.hoverSound.isControlSupported(FloatControl.Type.MASTER_GAIN)) {
                    FloatControl gainControl = (FloatControl)this.hoverSound.getControl(FloatControl.Type.MASTER_GAIN);
                    gainControl.setValue(gainControl.getMaximum());
                }
                this.hoverSound.setFramePosition(0);
                this.hoverSound.start();
            }
            catch (Exception exception) {
                // empty catch block
            }
        }
    }

    private void addButtonEffects(final JButton button) {
        button.addMouseListener(new MouseAdapter(){

            @Override
            public void mouseClicked(MouseEvent e) {
                PatternSelectionWindow.this.playClickSound();
            }

            @Override
            public void mouseEntered(MouseEvent e) {
                button.setCursor(PatternSelectionWindow.this.clickableCursor);
                PatternSelectionWindow.this.playHoverSound();
            }

            @Override
            public void mouseExited(MouseEvent e) {
                button.setCursor(PatternSelectionWindow.this.normalCursor);
            }
        });
    }

    private void addTextFieldEffects(final JTextField textField) {
        textField.addMouseListener(new MouseAdapter(){

            @Override
            public void mouseEntered(MouseEvent e) {
                textField.setCursor(PatternSelectionWindow.this.textCursor);
                PatternSelectionWindow.this.playHoverSound();
            }

            @Override
            public void mouseExited(MouseEvent e) {
                textField.setCursor(PatternSelectionWindow.this.normalCursor);
            }
        });
    }
}
