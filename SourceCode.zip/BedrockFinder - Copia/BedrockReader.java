/*
 * Decompiled with CFR 0.152.
 */
package com.mike;

import com.mike.extracted.AbstractRandom;
import com.mike.extracted.MathHelper;
import com.mike.extracted.RandomDeriver;
import com.mike.extracted.RandomProvider;
import com.mike.recreated.Identifier;

public class BedrockReader {
    RandomDeriver randomDeriver;
    BedrockType bedrockType;

    public BedrockReader(long seed, BedrockType bedrockType) {
        this.bedrockType = bedrockType;
        this.randomDeriver = RandomProvider.XOROSHIRO.create(seed).createRandomDeriver();
    }

    boolean isBedrock(int x, int y, int z) {
        double probabilityValue = 0.0;
        if (this.bedrockType == BedrockType.BEDROCK_FLOOR) {
            if (y == this.bedrockType.min) {
                return true;
            }
            if (y > this.bedrockType.max) {
                return false;
            }
            probabilityValue = MathHelper.lerpFromProgress(y, this.bedrockType.min, this.bedrockType.max, 1.0, 0.0);
        } else if (this.bedrockType == BedrockType.BEDROCK_ROOF) {
            if (y == this.bedrockType.min) {
                return true;
            }
            if (y < this.bedrockType.max) {
                return false;
            }
            probabilityValue = MathHelper.lerpFromProgress(y, this.bedrockType.max, this.bedrockType.min, 1.0, 0.0);
        }
        AbstractRandom abstractRandom = this.randomDeriver.createRandom(x, y, z);
        return (double)abstractRandom.nextFloat() < probabilityValue;
    }

    public static enum BedrockType {
        BEDROCK_FLOOR(new Identifier("bedrock_floor"), -64, -59),
        BEDROCK_ROOF(new Identifier("bedrock_roof"), 128, 123);

        public final Identifier id;
        public final int min;
        public final int max;

        private BedrockType(Identifier id, int min, int max) {
            this.id = id;
            this.min = min;
            this.max = max;
        }
    }
}
