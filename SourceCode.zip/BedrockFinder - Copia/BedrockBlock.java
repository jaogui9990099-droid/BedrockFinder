/*
 * Decompiled with CFR 0.152.
 */
package com.mike;

public class BedrockBlock {
    int x;
    int y;
    int z;
    BlockState state;

    public BedrockBlock(String arg) {
        String[] parts = arg.split(",");
        this.x = Integer.parseInt(parts[0]);
        this.y = Integer.parseInt(parts[1]);
        this.z = Integer.parseInt(parts[2]);
        this.state = parts.length > 3 ? BlockState.valueOf(parts[3]) : BlockState.NONE;
    }

    public BedrockBlock(int x, int y, int z, BlockState state) {
        this.x = x;
        this.y = y;
        this.z = z;
        this.state = state;
    }

    public BedrockBlock(int x, int y, int z) {
        this.x = x;
        this.y = y;
        this.z = z;
        this.state = BlockState.NONE;
    }

    public String toString() {
        return "BedrockBlock{x=" + this.x + ", y=" + this.y + ", z=" + this.z + ", state=" + String.valueOf((Object)this.state) + "}";
    }

    public boolean shouldBeBedrock() {
        return this.state == BlockState.SUSPECT || this.state == BlockState.CERTAIN;
    }

    public boolean isCertain() {
        return this.state == BlockState.CERTAIN;
    }

    public static enum BlockState {
        NONE,
        BLUE,
        SUSPECT,
        CERTAIN;

    }
}
