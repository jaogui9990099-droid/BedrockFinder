/*
 * Decompiled with CFR 0.152.
 */
package com.mike;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Component;
import java.awt.Cursor;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.Font;
import java.awt.Point;
import java.awt.Toolkit;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.io.InputStream;
import javax.sound.sampled.AudioInputStream;
import javax.sound.sampled.AudioSystem;
import javax.sound.sampled.Clip;
import javax.sound.sampled.FloatControl;
import javax.swing.BorderFactory;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;
import javax.swing.border.EmptyBorder;

public class HelpWindow
extends JFrame {
    private Cursor normalCursor;
    private Cursor clickableCursor;
    private Cursor textCursor;
    private Clip clickSound;
    private Clip hoverSound;

    public HelpWindow() {
        this.initializeCustomResources();
        this.initializeWindow();
        this.createContent();
        this.setVisible(true);
    }

    private void initializeCustomResources() {
        try {
            AudioInputStream audioInputStream;
            InputStream mouseStream = this.getClass().getResourceAsStream("/Assets/Images/Mouse.png");
            InputStream mouseClickStream = this.getClass().getResourceAsStream("/Assets/Images/Mouse_Click.png");
            InputStream mouseTextStream = this.getClass().getResourceAsStream("/Assets/Images/Mouse_Text.png");
            if (mouseStream != null && mouseClickStream != null && mouseTextStream != null) {
                ImageIcon mouseIcon = new ImageIcon(mouseStream.readAllBytes());
                ImageIcon mouseClickIcon = new ImageIcon(mouseClickStream.readAllBytes());
                ImageIcon mouseTextIcon = new ImageIcon(mouseTextStream.readAllBytes());
                this.normalCursor = Toolkit.getDefaultToolkit().createCustomCursor(mouseIcon.getImage(), new Point(0, 0), "NormalCursor");
                this.clickableCursor = Toolkit.getDefaultToolkit().createCustomCursor(mouseClickIcon.getImage(), new Point(0, 0), "ClickableCursor");
                this.textCursor = Toolkit.getDefaultToolkit().createCustomCursor(mouseTextIcon.getImage(), new Point(0, 0), "TextCursor");
            } else {
                this.normalCursor = Cursor.getDefaultCursor();
                this.clickableCursor = Cursor.getPredefinedCursor(12);
                this.textCursor = Cursor.getPredefinedCursor(2);
            }
            InputStream clickSoundStream = this.getClass().getResourceAsStream("/Assets/Sounds/Click.mp3");
            InputStream hoverSoundStream = this.getClass().getResourceAsStream("/Assets/Sounds/Mouse.mp3");
            if (clickSoundStream != null) {
                audioInputStream = AudioSystem.getAudioInputStream(clickSoundStream);
                this.clickSound = AudioSystem.getClip();
                this.clickSound.open(audioInputStream);
            }
            if (hoverSoundStream != null) {
                audioInputStream = AudioSystem.getAudioInputStream(hoverSoundStream);
                this.hoverSound = AudioSystem.getClip();
                this.hoverSound.open(audioInputStream);
            }
        }
        catch (Exception e) {
            System.err.println("Error loading custom resources: " + e.getMessage());
            this.normalCursor = Cursor.getDefaultCursor();
            this.clickableCursor = Cursor.getPredefinedCursor(12);
            this.textCursor = Cursor.getPredefinedCursor(2);
        }
    }

    private void initializeWindow() {
        this.setTitle("Help");
        this.setDefaultCloseOperation(2);
        this.setLayout(new BorderLayout());
        this.setResizable(false);
        this.setSize(500, 400);
        this.setLocationRelativeTo(null);
        try {
            InputStream iconStream = this.getClass().getResourceAsStream("/Assets/Images/App-Icon.png");
            if (iconStream != null) {
                ImageIcon icon = new ImageIcon(iconStream.readAllBytes());
                this.setIconImage(icon.getImage());
            }
        }
        catch (Exception e) {
            System.err.println("Could not load application icon: " + e.getMessage());
        }
        this.setCursor(this.normalCursor);
        this.getContentPane().setBackground(Color.BLACK);
    }

    private void createContent() {
        JPanel mainPanel = new JPanel(new BorderLayout());
        mainPanel.setBackground(Color.BLACK);
        mainPanel.setBorder(new EmptyBorder(20, 20, 20, 20));
        JTextArea helpText = new JTextArea();
        helpText.setEditable(false);
        helpText.setBackground(Color.BLACK);
        helpText.setForeground(Color.WHITE);
        helpText.setFont(new Font("Arial", 0, 12));
        helpText.setLineWrap(true);
        helpText.setWrapStyleWord(true);
        helpText.setText("\ud83e\udea8 Bedrock Finder Help\n\n1. How to Find Bases with Bedrock\nUse the start command in the command line.\nEnter the bedrock pattern on the 16\u00d716 grid using these colors:\n\ud83d\udd35 Blue = other blocks (not bedrock)\n\ud83d\udfe2 Green = possible bedrock\n\ud83d\udd34 Red = confirmed bedrock\n\nIn the textbox, choose a scan level from 0 to 4:\n0 \u2192 scan all bedrock layers\n1 \u2192 scan Y = -61\n2 \u2192 scan Y = -62\n3 \u2192 scan Y = -63\n4 \u2192 scan Y = -64\n\nPress Continue, then enter the world seed.\nPress OK, then choose:\n\"yes\" to start scanning\n\"no\" to go back\n\n2. Grid Command\nUse grid match to view the exact bedrock pattern found by the app.\nUse grid possible to view patterns that are similar to the one you selected (not an exact match).\n\n3. Stop Command\nUse stop to cancel the current scanning process.\n\n4. Coords Command\nUse coords to display the current coordinates being scanned by the app.");
        JScrollPane scrollPane = new JScrollPane(helpText);
        scrollPane.setVerticalScrollBarPolicy(20);
        scrollPane.setHorizontalScrollBarPolicy(31);
        scrollPane.setBorder(BorderFactory.createLoweredBevelBorder());
        mainPanel.add((Component)scrollPane, "Center");
        JPanel buttonPanel = new JPanel(new FlowLayout());
        buttonPanel.setBackground(Color.BLACK);
        JButton understoodButton = new JButton("Understood");
        understoodButton.setPreferredSize(new Dimension(100, 30));
        understoodButton.addActionListener(new ActionListener(){

            @Override
            public void actionPerformed(ActionEvent e) {
                HelpWindow.this.dispose();
            }
        });
        this.addButtonEffects(understoodButton);
        buttonPanel.add(understoodButton);
        mainPanel.add((Component)buttonPanel, "South");
        this.add((Component)mainPanel, "Center");
    }

    private void addButtonEffects(final JButton button) {
        button.addMouseListener(new MouseAdapter(){

            @Override
            public void mouseClicked(MouseEvent e) {
                HelpWindow.this.playClickSound();
            }

            @Override
            public void mouseEntered(MouseEvent e) {
                button.setCursor(HelpWindow.this.clickableCursor);
                HelpWindow.this.playHoverSound();
            }

            @Override
            public void mouseExited(MouseEvent e) {
                button.setCursor(HelpWindow.this.normalCursor);
            }
        });
    }

    private void playClickSound() {
        try {
            if (this.clickSound != null) {
                if (this.clickSound.isControlSupported(FloatControl.Type.MASTER_GAIN)) {
                    FloatControl gainControl = (FloatControl)this.clickSound.getControl(FloatControl.Type.MASTER_GAIN);
                    gainControl.setValue(gainControl.getMaximum());
                }
                this.clickSound.setFramePosition(0);
                this.clickSound.start();
            }
        }
        catch (Exception exception) {
            // empty catch block
        }
    }

    private void playHoverSound() {
        try {
            if (this.hoverSound != null) {
                if (this.hoverSound.isControlSupported(FloatControl.Type.MASTER_GAIN)) {
                    FloatControl gainControl = (FloatControl)this.hoverSound.getControl(FloatControl.Type.MASTER_GAIN);
                    gainControl.setValue(gainControl.getMaximum());
                }
                this.hoverSound.setFramePosition(0);
                this.hoverSound.start();
            }
        }
        catch (Exception exception) {
            // empty catch block
        }
    }
}
