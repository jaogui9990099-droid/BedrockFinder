/*
 * Decompiled with CFR 0.152.
 */
package com.mike;

import com.mike.BedrockFinderGUI;
import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Component;
import java.awt.Cursor;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.GridLayout;
import java.awt.Image;
import java.awt.Point;
import java.awt.RenderingHints;
import java.awt.Toolkit;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.io.InputStream;
import javax.sound.sampled.AudioInputStream;
import javax.sound.sampled.AudioSystem;
import javax.sound.sampled.Clip;
import javax.sound.sampled.FloatControl;
import javax.swing.BorderFactory;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;

public class ResultVisualizationWindow
extends JFrame {
    private static final int CELL_SIZE = 30;
    private static final int GRID_SIZE = 16;
    private Cursor normalCursor;
    private Cursor clickableCursor;
    private Cursor textCursor;
    private Clip clickSound;
    private Clip hoverSound;
    private BedrockFinderGUI.MatchResult matchResult;
    private JPanel gridPanel;
    private JLabel infoLabel;

    public ResultVisualizationWindow(BedrockFinderGUI.MatchResult matchResult) {
        this.matchResult = matchResult;
        this.initializeCustomResources();
        this.initializeWindow();
        this.createComponents();
        this.layoutComponents();
    }

    private void initializeCustomResources() {
        try {
            AudioInputStream audioInputStream;
            InputStream mouseStream = this.getClass().getResourceAsStream("/Assets/Images/Mouse.png");
            InputStream mouseClickStream = this.getClass().getResourceAsStream("/Assets/Images/Mouse_Click.png");
            InputStream mouseTextStream = this.getClass().getResourceAsStream("/Assets/Images/Mouse_Text.png");
            if (mouseStream != null && mouseClickStream != null && mouseTextStream != null) {
                Image mouseImage = new ImageIcon(mouseStream.readAllBytes()).getImage();
                Image mouseClickImage = new ImageIcon(mouseClickStream.readAllBytes()).getImage();
                Image mouseTextImage = new ImageIcon(mouseTextStream.readAllBytes()).getImage();
                this.normalCursor = Toolkit.getDefaultToolkit().createCustomCursor(mouseImage, new Point(0, 0), "Normal");
                this.clickableCursor = Toolkit.getDefaultToolkit().createCustomCursor(mouseClickImage, new Point(0, 0), "Clickable");
                this.textCursor = Toolkit.getDefaultToolkit().createCustomCursor(mouseTextImage, new Point(0, 0), "Text");
            } else {
                this.normalCursor = Cursor.getDefaultCursor();
                this.clickableCursor = Cursor.getPredefinedCursor(12);
                this.textCursor = Cursor.getPredefinedCursor(2);
            }
            InputStream clickSoundStream = this.getClass().getResourceAsStream("/Assets/Sounds/Click.mp3");
            InputStream hoverSoundStream = this.getClass().getResourceAsStream("/Assets/Sounds/Mouse.mp3");
            if (clickSoundStream != null) {
                audioInputStream = AudioSystem.getAudioInputStream(clickSoundStream);
                this.clickSound = AudioSystem.getClip();
                this.clickSound.open(audioInputStream);
            }
            if (hoverSoundStream != null) {
                audioInputStream = AudioSystem.getAudioInputStream(hoverSoundStream);
                this.hoverSound = AudioSystem.getClip();
                this.hoverSound.open(audioInputStream);
            }
        }
        catch (Exception e) {
            System.err.println("Erro ao carregar recursos personalizados: " + e.getMessage());
            this.normalCursor = Cursor.getDefaultCursor();
            this.clickableCursor = Cursor.getPredefinedCursor(12);
            this.textCursor = Cursor.getPredefinedCursor(2);
        }
    }

    private void initializeWindow() {
        this.setTitle("Pattern Match Visualization");
        this.setDefaultCloseOperation(2);
        this.setLayout(new BorderLayout());
        this.setResizable(false);
        this.setSize(600, 700);
        this.setLocationRelativeTo(null);
        try {
            InputStream iconStream = this.getClass().getResourceAsStream("/Assets/Images/App-Icon.png");
            if (iconStream != null) {
                ImageIcon icon = new ImageIcon(iconStream.readAllBytes());
                this.setIconImage(icon.getImage());
            }
        }
        catch (Exception e) {
            System.err.println("Could not load application icon: " + e.getMessage());
        }
        this.setCursor(this.normalCursor);
        this.getContentPane().setBackground(Color.BLACK);
    }

    private void createComponents() {
        this.gridPanel = new JPanel(){

            @Override
            protected void paintComponent(Graphics g) {
                super.paintComponent(g);
                ResultVisualizationWindow.this.drawGrid(g);
            }
        };
        this.gridPanel.setPreferredSize(new Dimension(480, 480));
        this.gridPanel.setBackground(Color.BLACK);
        this.infoLabel = new JLabel();
        this.infoLabel.setForeground(Color.WHITE);
        this.infoLabel.setHorizontalAlignment(0);
        this.updateInfoLabel();
        JButton closeButton = new JButton("Close");
        closeButton.setBackground(Color.DARK_GRAY);
        closeButton.setForeground(Color.WHITE);
        closeButton.setFocusPainted(false);
        closeButton.addActionListener(e -> this.dispose());
        this.addButtonEffects(closeButton);
    }

    private void layoutComponents() {
        JPanel topPanel = new JPanel(new BorderLayout());
        topPanel.setBackground(Color.BLACK);
        topPanel.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));
        topPanel.add((Component)this.infoLabel, "Center");
        JPanel centerPanel = new JPanel(new FlowLayout());
        centerPanel.setBackground(Color.BLACK);
        centerPanel.add(this.gridPanel);
        JPanel bottomPanel = new JPanel(new BorderLayout());
        bottomPanel.setBackground(Color.BLACK);
        bottomPanel.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));
        JPanel legendPanel = this.createLegendPanel();
        JButton closeButton = new JButton("Close");
        closeButton.setBackground(Color.DARK_GRAY);
        closeButton.setForeground(Color.WHITE);
        closeButton.setFocusPainted(false);
        closeButton.addActionListener(e -> this.dispose());
        bottomPanel.add((Component)legendPanel, "Center");
        bottomPanel.add((Component)closeButton, "South");
        this.add((Component)topPanel, "North");
        this.add((Component)centerPanel, "Center");
        this.add((Component)bottomPanel, "South");
    }

    private JPanel createLegendPanel() {
        JPanel legendPanel = new JPanel(new GridLayout(2, 2, 10, 5));
        legendPanel.setBackground(Color.BLACK);
        legendPanel.add(this.createLegendItem(Color.GRAY, "Other blocks"));
        legendPanel.add(this.createLegendItem(Color.GREEN, "Bedrock"));
        legendPanel.add(this.createLegendItem(Color.BLUE, "Pattern match"));
        legendPanel.add(this.createLegendItem(Color.RED, "Pattern mismatch"));
        return legendPanel;
    }

    private JPanel createLegendItem(Color color, String text) {
        JPanel item = new JPanel(new FlowLayout(0, 5, 0));
        item.setBackground(Color.BLACK);
        JPanel colorBox = new JPanel();
        colorBox.setBackground(color);
        colorBox.setPreferredSize(new Dimension(20, 20));
        colorBox.setBorder(BorderFactory.createLineBorder(Color.WHITE));
        JLabel label = new JLabel(text);
        label.setForeground(Color.WHITE);
        item.add(colorBox);
        item.add(label);
        return item;
    }

    private void updateInfoLabel() {
        String info = String.format("<html><center><b>Pattern Match Found!</b><br>Coordinates: X=%d, Z=%d, Y=%d<br>Grid shows 16x16 area around match</center></html>", this.matchResult.centerX, this.matchResult.centerZ, this.matchResult.y);
        this.infoLabel.setText(info);
    }

    private void drawGrid(Graphics g) {
        Graphics2D g2d = (Graphics2D)g;
        g2d.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
        int i = 0;
        while (i < 16) {
            int j = 0;
            while (j < 16) {
                int x = i * 30;
                int y = j * 30;
                Color cellColor = this.getCellColor(i, j);
                g2d.setColor(cellColor);
                g2d.fillRect(x, y, 30, 30);
                g2d.setColor(Color.WHITE);
                g2d.drawRect(x, y, 30, 30);
                if (i == 8 && j == 8) {
                    g2d.setColor(Color.YELLOW);
                    g2d.fillOval(x + 15 - 3, y + 15 - 3, 6, 6);
                }
                ++j;
            }
            ++i;
        }
    }

    private Color getCellColor(int gridX, int gridZ) {
        boolean isBedrock = this.matchResult.bedrockGrid[gridX][gridZ];
        boolean isPattern = this.matchResult.patternGrid[gridX][gridZ];
        boolean isMatch = this.matchResult.matchGrid[gridX][gridZ];
        if (isPattern) {
            if (isMatch) {
                return Color.BLUE;
            }
            return Color.RED;
        }
        if (isBedrock) {
            return Color.GREEN;
        }
        return Color.GRAY;
    }

    private void addButtonEffects(JButton button) {
        button.setCursor(this.clickableCursor);
        button.addMouseListener(new MouseAdapter(){

            @Override
            public void mouseEntered(MouseEvent e) {
                ResultVisualizationWindow.this.playHoverSound();
            }

            @Override
            public void mousePressed(MouseEvent e) {
                ResultVisualizationWindow.this.playClickSound();
            }
        });
    }

    private void playClickSound() {
        if (this.clickSound != null) {
            try {
                if (this.clickSound.isControlSupported(FloatControl.Type.MASTER_GAIN)) {
                    FloatControl gainControl = (FloatControl)this.clickSound.getControl(FloatControl.Type.MASTER_GAIN);
                    gainControl.setValue(gainControl.getMaximum());
                }
                this.clickSound.setFramePosition(0);
                this.clickSound.start();
            }
            catch (Exception exception) {
                // empty catch block
            }
        }
    }

    private void playHoverSound() {
        if (this.hoverSound != null) {
            try {
                if (this.hoverSound.isControlSupported(FloatControl.Type.MASTER_GAIN)) {
                    FloatControl gainControl = (FloatControl)this.hoverSound.getControl(FloatControl.Type.MASTER_GAIN);
                    gainControl.setValue(gainControl.getMaximum());
                }
                this.hoverSound.setFramePosition(0);
                this.hoverSound.start();
            }
            catch (Exception exception) {
                // empty catch block
            }
        }
    }
}
