/*
 * Decompiled with CFR 0.152.
 */
package com.mike;

import java.awt.Color;
import java.awt.Graphics2D;
import java.awt.Image;
import java.awt.RenderingHints;
import java.awt.SystemTray;
import java.awt.TrayIcon;
import java.awt.image.BufferedImage;

public class SystemNotification {
    private static SystemTray tray;
    private static TrayIcon trayIcon;
    private static boolean isInitialized;

    static {
        isInitialized = false;
    }

    public static void initialize() {
        System.out.println("[INFO] System notifications are disabled");
    }

    public static void showPatternFoundNotification() {
        System.out.println("[INFO] Pattern found notification disabled");
    }

    private static Image createTrayIcon() {
        int size = 16;
        BufferedImage image = new BufferedImage(size, size, 2);
        Graphics2D g2d = image.createGraphics();
        g2d.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
        g2d.setColor(Color.DARK_GRAY);
        g2d.fillRect(0, 0, size, size);
        g2d.setColor(Color.GRAY);
        g2d.fillRect(2, 2, 4, 4);
        g2d.fillRect(10, 2, 4, 4);
        g2d.fillRect(6, 6, 4, 4);
        g2d.fillRect(2, 10, 4, 4);
        g2d.fillRect(10, 10, 4, 4);
        g2d.setColor(Color.BLACK);
        g2d.drawRect(0, 0, size - 1, size - 1);
        g2d.dispose();
        return image;
    }

    public static void cleanup() {
        if (isInitialized && tray != null && trayIcon != null) {
            tray.remove(trayIcon);
            isInitialized = false;
        }
    }
}
