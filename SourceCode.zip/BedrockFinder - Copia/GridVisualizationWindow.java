/*
 * Decompiled with CFR 0.152.
 */
package com.mike;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Component;
import java.awt.Cursor;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.Font;
import java.awt.GridLayout;
import java.awt.Point;
import java.awt.Toolkit;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.io.InputStream;
import javax.sound.sampled.AudioInputStream;
import javax.sound.sampled.AudioSystem;
import javax.sound.sampled.Clip;
import javax.sound.sampled.FloatControl;
import javax.swing.BorderFactory;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;

public class GridVisualizationWindow
extends JFrame {
    private static final int GRID_SIZE = 16;
    private static final int BUTTON_SIZE = 30;
    private static final Color BEDROCK_COLOR = new Color(0, 200, 0);
    private static final Color NON_BEDROCK_COLOR = new Color(128, 128, 128);
    private static final Color PATTERN_COLOR = new Color(200, 0, 0);
    private static final Color MATCH_COLOR = new Color(200, 0, 0);
    private static final Color NO_MATCH_COLOR = new Color(200, 0, 0);
    private JButton[][] gridButtons;
    private String gridData;
    private String gridType;
    private int centerX;
    private int centerZ;
    private int y;
    private Cursor normalCursor;
    private Cursor clickableCursor;
    private Cursor textCursor;
    private Clip clickSound;
    private Clip hoverSound;

    public GridVisualizationWindow(String gridData, String gridType, int centerX, int centerZ, int y) {
        this.gridData = gridData;
        this.gridType = gridType;
        this.centerX = centerX;
        this.centerZ = centerZ;
        this.y = y;
        this.initializeCustomResources();
        this.initializeWindow();
        this.parseAndDisplayGrid();
    }

    private void initializeCustomResources() {
        try {
            AudioInputStream audioInputStream;
            InputStream mouseStream = this.getClass().getResourceAsStream("/Assets/Images/Mouse.png");
            InputStream mouseClickStream = this.getClass().getResourceAsStream("/Assets/Images/Mouse_Click.png");
            InputStream mouseTextStream = this.getClass().getResourceAsStream("/Assets/Images/Mouse_Text.png");
            if (mouseStream != null && mouseClickStream != null && mouseTextStream != null) {
                ImageIcon mouseIcon = new ImageIcon(mouseStream.readAllBytes());
                ImageIcon mouseClickIcon = new ImageIcon(mouseClickStream.readAllBytes());
                ImageIcon mouseTextIcon = new ImageIcon(mouseTextStream.readAllBytes());
                this.normalCursor = Toolkit.getDefaultToolkit().createCustomCursor(mouseIcon.getImage(), new Point(0, 0), "NormalCursor");
                this.clickableCursor = Toolkit.getDefaultToolkit().createCustomCursor(mouseClickIcon.getImage(), new Point(0, 0), "ClickableCursor");
                this.textCursor = Toolkit.getDefaultToolkit().createCustomCursor(mouseTextIcon.getImage(), new Point(0, 0), "TextCursor");
            } else {
                this.normalCursor = Cursor.getDefaultCursor();
                this.clickableCursor = Cursor.getPredefinedCursor(12);
                this.textCursor = Cursor.getPredefinedCursor(2);
            }
            InputStream clickSoundStream = this.getClass().getResourceAsStream("/Assets/Sounds/Click.mp3");
            InputStream hoverSoundStream = this.getClass().getResourceAsStream("/Assets/Sounds/Mouse.mp3");
            if (clickSoundStream != null) {
                audioInputStream = AudioSystem.getAudioInputStream(clickSoundStream);
                this.clickSound = AudioSystem.getClip();
                this.clickSound.open(audioInputStream);
            }
            if (hoverSoundStream != null) {
                audioInputStream = AudioSystem.getAudioInputStream(hoverSoundStream);
                this.hoverSound = AudioSystem.getClip();
                this.hoverSound.open(audioInputStream);
            }
        }
        catch (Exception e) {
            System.err.println("Error loading custom resources: " + e.getMessage());
            this.normalCursor = Cursor.getDefaultCursor();
            this.clickableCursor = Cursor.getPredefinedCursor(12);
            this.textCursor = Cursor.getPredefinedCursor(2);
        }
    }

    private void initializeWindow() {
        this.setTitle("Grid Visualization - " + this.gridType);
        this.setDefaultCloseOperation(2);
        this.setResizable(false);
        try {
            InputStream iconStream = this.getClass().getResourceAsStream("/Assets/Images/App-Icon.png");
            if (iconStream != null) {
                ImageIcon icon = new ImageIcon(iconStream.readAllBytes());
                this.setIconImage(icon.getImage());
            }
        }
        catch (Exception e) {
            System.err.println("Could not load application icon: " + e.getMessage());
        }
        this.setCursor(this.normalCursor);
        this.setLayout(new BorderLayout());
        this.getContentPane().setBackground(new Color(64, 64, 64));
        JPanel infoPanel = this.createInfoPanel();
        this.add((Component)infoPanel, "North");
        JPanel gridPanel = this.createGridPanel();
        this.add((Component)gridPanel, "Center");
        JPanel controlPanel = this.createControlPanel();
        this.add((Component)controlPanel, "South");
        this.pack();
        this.setLocationRelativeTo(null);
    }

    private JPanel createInfoPanel() {
        JPanel panel = new JPanel(new GridLayout(2, 1));
        panel.setBorder(BorderFactory.createEmptyBorder(10, 10, 5, 10));
        panel.setBackground(new Color(64, 64, 64));
        JLabel titleLabel = new JLabel("Grid " + this.gridType + " - Coordinates: (" + this.centerX + ", " + this.y + ", " + this.centerZ + ")", 0);
        titleLabel.setFont(new Font("Arial", 1, 14));
        titleLabel.setForeground(Color.WHITE);
        JLabel legendLabel = new JLabel("<html><center><span style='color: rgb(128,128,128);'>\u25a0</span> Non-Bedrock | <span style='color: rgb(0,200,0);'>\u25a0</span> Bedrock | <span style='color: rgb(200,0,0);'>\u25a0</span> Pattern Found</center></html>", 0);
        legendLabel.setForeground(Color.WHITE);
        panel.add(titleLabel);
        panel.add(legendLabel);
        return panel;
    }

    private JPanel createGridPanel() {
        JPanel panel = new JPanel(new GridLayout(16, 16, 1, 1));
        panel.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));
        panel.setBackground(Color.BLACK);
        this.gridButtons = new JButton[16][16];
        int i = 0;
        while (i < 16) {
            int j = 0;
            while (j < 16) {
                JButton button = new JButton();
                button.setPreferredSize(new Dimension(30, 30));
                button.setBackground(NON_BEDROCK_COLOR);
                button.setBorder(BorderFactory.createLineBorder(Color.GRAY, 1));
                button.setFocusPainted(false);
                int worldX = this.centerX + (j - 8);
                int worldZ = this.centerZ + (i - 8);
                button.setToolTipText("(" + worldX + ", " + this.y + ", " + worldZ + ")");
                this.addButtonEffects(button);
                this.gridButtons[i][j] = button;
                panel.add(button);
                ++j;
            }
            ++i;
        }
        return panel;
    }

    private JPanel createControlPanel() {
        JPanel panel = new JPanel(new FlowLayout());
        panel.setBorder(BorderFactory.createEmptyBorder(5, 10, 10, 10));
        panel.setBackground(Color.BLACK);
        JButton closeButton = new JButton("Close");
        closeButton.setBackground(Color.DARK_GRAY);
        closeButton.setForeground(Color.WHITE);
        closeButton.addActionListener(e -> this.dispose());
        this.addButtonEffects(closeButton);
        panel.add(closeButton);
        return panel;
    }

    private void parseAndDisplayGrid() {
        if (this.gridData == null || this.gridData.trim().isEmpty()) {
            int i = 0;
            while (i < 16) {
                int j = 0;
                while (j < 16) {
                    this.gridButtons[i][j].setBackground(NON_BEDROCK_COLOR);
                    ++j;
                }
                ++i;
            }
            return;
        }
        String[] lines = this.gridData.split("\n");
        int i = 0;
        while (i < 16 && i < lines.length) {
            String line = lines[i].trim();
            int j = 0;
            while (j < 16 && j < line.length()) {
                char c = line.charAt(j);
                Color color = NON_BEDROCK_COLOR;
                switch (c) {
                    case '1': 
                    case 'B': 
                    case '\u25a0': {
                        color = BEDROCK_COLOR;
                        break;
                    }
                    case '.': 
                    case '0': 
                    case 'N': 
                    case '\u25a1': {
                        color = NON_BEDROCK_COLOR;
                        break;
                    }
                    case 'P': {
                        color = PATTERN_COLOR;
                        break;
                    }
                    case 'M': {
                        color = MATCH_COLOR;
                        break;
                    }
                    case 'X': {
                        color = NO_MATCH_COLOR;
                        break;
                    }
                    default: {
                        color = NON_BEDROCK_COLOR;
                    }
                }
                this.gridButtons[i][j].setBackground(color);
                ++j;
            }
            ++i;
        }
    }

    private void addButtonEffects(JButton button) {
        button.setCursor(this.clickableCursor);
        button.addMouseListener(new MouseAdapter(){

            @Override
            public void mouseEntered(MouseEvent e) {
                GridVisualizationWindow.this.playHoverSound();
            }

            @Override
            public void mousePressed(MouseEvent e) {
                GridVisualizationWindow.this.playClickSound();
            }
        });
    }

    private void playClickSound() {
        if (this.clickSound != null) {
            try {
                if (this.clickSound.isControlSupported(FloatControl.Type.MASTER_GAIN)) {
                    FloatControl gainControl = (FloatControl)this.clickSound.getControl(FloatControl.Type.MASTER_GAIN);
                    gainControl.setValue(gainControl.getMaximum());
                }
                this.clickSound.setFramePosition(0);
                this.clickSound.start();
            }
            catch (Exception exception) {
                // empty catch block
            }
        }
    }

    private void playHoverSound() {
        if (this.hoverSound != null) {
            try {
                if (this.hoverSound.isControlSupported(FloatControl.Type.MASTER_GAIN)) {
                    FloatControl gainControl = (FloatControl)this.hoverSound.getControl(FloatControl.Type.MASTER_GAIN);
                    gainControl.setValue(gainControl.getMaximum());
                }
                this.hoverSound.setFramePosition(0);
                this.hoverSound.start();
            }
            catch (Exception exception) {
                // empty catch block
            }
        }
    }
}
