/*
 * Decompiled with CFR 0.152.
 */
package com.mike;

import com.mike.BedrockBlock;
import com.mike.BedrockReader;
import com.mike.GridVisualizationWindow;
import com.mike.HelpWindow;
import com.mike.PatternSelectionWindow;
import com.mike.SystemNotification;
import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Component;
import java.awt.Cursor;
import java.awt.FlowLayout;
import java.awt.Font;
import java.awt.Point;
import java.awt.Toolkit;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStream;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.atomic.AtomicBoolean;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.concurrent.atomic.AtomicLong;
import javax.sound.sampled.AudioInputStream;
import javax.sound.sampled.AudioSystem;
import javax.sound.sampled.Clip;
import javax.sound.sampled.FloatControl;
import javax.swing.BorderFactory;
import javax.swing.Box;
import javax.swing.ImageIcon;
import javax.swing.JFileChooser;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;
import javax.swing.JTextField;
import javax.swing.SwingUtilities;
import javax.swing.Timer;
import javax.swing.border.EmptyBorder;
import javax.swing.filechooser.FileNameExtensionFilter;

public class BedrockFinderGUI
extends JFrame {
    private JTextArea outputArea;
    private JTextField inputField;
    private JTextField xStartField;
    private JTextField zStartField;
    private JLabel chunksScannedLabel;
    private JLabel scanningSpeedLabel;
    private Cursor normalCursor;
    private Cursor clickableCursor;
    private Cursor textCursor;
    private Clip clickSound;
    private Clip hoverSound;
    private AtomicBoolean isSearching = new AtomicBoolean(false);
    private AtomicBoolean isPaused = new AtomicBoolean(false);
    private AtomicLong chunksScanned = new AtomicLong(0L);
    private AtomicLong scanningSpeed = new AtomicLong(0L);
    private AtomicInteger matchesFound = new AtomicInteger(0);
    private Thread searchThread;
    private long currentSeed;
    private List<BedrockBlock> currentPattern;
    private BedrockReader bedrockReader;
    private String lastCoordinate = "N/A";
    private String matchGrid = "";
    private String possibleGrid = "";
    private int currentX = 0;
    private int currentZ = 0;
    private boolean stopOnFirstMatch = false;
    private int currentBedrockLayer = 0;
    private int maxChunks = 10000;
    private String[] previewParams = null;
    private Map<String, Boolean> bedrockCache = new ConcurrentHashMap<String, Boolean>();
    private AtomicLong cacheHits = new AtomicLong(0L);
    private AtomicLong cacheMisses = new AtomicLong(0L);
    private static final int MAX_CACHE_SIZE = 10000;
    private List<String> hiddenLogs = new ArrayList<String>();
    private boolean enableDetailedLogging = true;
    private List<SimilarityMatch> mediumSimilarityMatches = new ArrayList<SimilarityMatch>();
    private PatternSelectionWindow patternWindow;

    public BedrockFinderGUI() {
        this.initializeCustomResources();
        this.initializeGUI();
        SystemNotification.initialize();
    }

    private void initializeCustomResources() {
        try {
            AudioInputStream audioInputStream;
            InputStream mouseStream = this.getClass().getResourceAsStream("/Assets/Images/Mouse.png");
            InputStream mouseClickStream = this.getClass().getResourceAsStream("/Assets/Images/Mouse_Click.png");
            InputStream mouseTextStream = this.getClass().getResourceAsStream("/Assets/Images/Mouse_Text.png");
            if (mouseStream != null && mouseClickStream != null && mouseTextStream != null) {
                ImageIcon mouseIcon = new ImageIcon(mouseStream.readAllBytes());
                ImageIcon mouseClickIcon = new ImageIcon(mouseClickStream.readAllBytes());
                ImageIcon mouseTextIcon = new ImageIcon(mouseTextStream.readAllBytes());
                this.normalCursor = Toolkit.getDefaultToolkit().createCustomCursor(mouseIcon.getImage(), new Point(0, 0), "NormalCursor");
                this.clickableCursor = Toolkit.getDefaultToolkit().createCustomCursor(mouseClickIcon.getImage(), new Point(0, 0), "ClickableCursor");
                this.textCursor = Toolkit.getDefaultToolkit().createCustomCursor(mouseTextIcon.getImage(), new Point(0, 0), "TextCursor");
            } else {
                this.normalCursor = Cursor.getDefaultCursor();
                this.clickableCursor = Cursor.getPredefinedCursor(12);
                this.textCursor = Cursor.getPredefinedCursor(2);
            }
            InputStream clickSoundStream = this.getClass().getResourceAsStream("/Assets/Sounds/Click.mp3");
            InputStream hoverSoundStream = this.getClass().getResourceAsStream("/Assets/Sounds/Mouse.mp3");
            if (clickSoundStream != null) {
                audioInputStream = AudioSystem.getAudioInputStream(clickSoundStream);
                this.clickSound = AudioSystem.getClip();
                this.clickSound.open(audioInputStream);
            }
            if (hoverSoundStream != null) {
                audioInputStream = AudioSystem.getAudioInputStream(hoverSoundStream);
                this.hoverSound = AudioSystem.getClip();
                this.hoverSound.open(audioInputStream);
            }
        }
        catch (Exception e) {
            System.err.println("Error loading custom resources: " + e.getMessage());
            this.normalCursor = Cursor.getDefaultCursor();
            this.clickableCursor = Cursor.getPredefinedCursor(12);
            this.textCursor = Cursor.getPredefinedCursor(2);
        }
    }

    private void initializeGUI() {
        this.setTitle("Bedrock Finder");
        this.setDefaultCloseOperation(3);
        this.setExtendedState(6);
        this.setLocationRelativeTo(null);
        try {
            InputStream iconStream = this.getClass().getResourceAsStream("/Assets/Images/App-Icon.png");
            if (iconStream != null) {
                ImageIcon icon = new ImageIcon(iconStream.readAllBytes());
                this.setIconImage(icon.getImage());
            }
        }
        catch (Exception e2) {
            System.err.println("Could not load application icon: " + e2.getMessage());
        }
        this.setCursor(this.normalCursor);
        this.setLayout(new BorderLayout());
        this.getContentPane().setBackground(Color.BLACK);
        JPanel topPanel = new JPanel(new BorderLayout());
        topPanel.setBackground(Color.BLACK);
        JLabel titleLabel = new JLabel("Bedrock Finder", 0);
        titleLabel.setFont(new Font("Arial", 1, 24));
        titleLabel.setForeground(Color.WHITE);
        titleLabel.setBorder(new EmptyBorder(10, 0, 10, 0));
        topPanel.add((Component)titleLabel, "Center");
        JPanel positionPanel = new JPanel(new FlowLayout(1, 20, 5));
        positionPanel.setBackground(Color.BLACK);
        JLabel xLabel = new JLabel("X Starting position:");
        xLabel.setForeground(Color.WHITE);
        xLabel.setFont(new Font("Arial", 0, 12));
        this.xStartField = new JTextField("0", 8);
        this.xStartField.setBackground(Color.DARK_GRAY);
        this.xStartField.setForeground(Color.WHITE);
        this.xStartField.setCaretColor(Color.WHITE);
        this.xStartField.setFont(new Font("Consolas", 0, 12));
        this.xStartField.setBorder(BorderFactory.createCompoundBorder(BorderFactory.createLineBorder(Color.GRAY), new EmptyBorder(3, 5, 3, 5)));
        this.addTextFieldEffects(this.xStartField);
        JLabel zLabel = new JLabel("Z Starting position:");
        zLabel.setForeground(Color.WHITE);
        zLabel.setFont(new Font("Arial", 0, 12));
        this.zStartField = new JTextField("0", 8);
        this.zStartField.setBackground(Color.DARK_GRAY);
        this.zStartField.setForeground(Color.WHITE);
        this.zStartField.setCaretColor(Color.WHITE);
        this.zStartField.setFont(new Font("Consolas", 0, 12));
        this.zStartField.setBorder(BorderFactory.createCompoundBorder(BorderFactory.createLineBorder(Color.GRAY), new EmptyBorder(3, 5, 3, 5)));
        this.addTextFieldEffects(this.zStartField);
        positionPanel.add(xLabel);
        positionPanel.add(this.xStartField);
        positionPanel.add(zLabel);
        positionPanel.add(this.zStartField);
        topPanel.add((Component)positionPanel, "South");
        this.add((Component)topPanel, "North");
        this.outputArea = new JTextArea();
        this.outputArea.setBackground(Color.BLACK);
        this.outputArea.setForeground(Color.WHITE);
        this.outputArea.setFont(new Font("Consolas", 0, 12));
        this.outputArea.setEditable(false);
        this.outputArea.setCaretColor(Color.WHITE);
        JScrollPane scrollPane = new JScrollPane(this.outputArea);
        scrollPane.setBackground(Color.BLACK);
        scrollPane.setBorder(BorderFactory.createLineBorder(Color.GRAY));
        scrollPane.setVerticalScrollBarPolicy(22);
        this.add((Component)scrollPane, "Center");
        JPanel bottomPanel = new JPanel(new BorderLayout());
        bottomPanel.setBackground(Color.BLACK);
        bottomPanel.setBorder(new EmptyBorder(5, 5, 5, 5));
        this.inputField = new JTextField();
        this.inputField.setBackground(Color.DARK_GRAY);
        this.inputField.setForeground(Color.WHITE);
        this.inputField.setCaretColor(Color.WHITE);
        this.inputField.setFont(new Font("Consolas", 0, 12));
        this.inputField.setBorder(BorderFactory.createCompoundBorder(BorderFactory.createLineBorder(Color.GRAY), new EmptyBorder(5, 5, 5, 5)));
        this.inputField.addActionListener(new ActionListener(){

            @Override
            public void actionPerformed(ActionEvent e) {
                BedrockFinderGUI.this.processCommand(BedrockFinderGUI.this.inputField.getText().trim());
                BedrockFinderGUI.this.inputField.setText("");
            }
        });
        this.addTextFieldEffects(this.inputField);
        bottomPanel.add((Component)this.inputField, "Center");
        JPanel statusPanel = new JPanel(new FlowLayout(2));
        statusPanel.setBackground(Color.BLACK);
        this.scanningSpeedLabel = new JLabel("Scanning 0 per second");
        this.scanningSpeedLabel.setForeground(Color.WHITE);
        this.scanningSpeedLabel.setFont(new Font("Arial", 0, 10));
        this.chunksScannedLabel = new JLabel("Chunks Scanned: 0");
        this.chunksScannedLabel.setForeground(Color.WHITE);
        this.chunksScannedLabel.setFont(new Font("Arial", 0, 10));
        statusPanel.add(this.scanningSpeedLabel);
        statusPanel.add(Box.createHorizontalStrut(20));
        statusPanel.add(this.chunksScannedLabel);
        JPanel bottomContainer = new JPanel(new BorderLayout());
        bottomContainer.setBackground(Color.BLACK);
        bottomContainer.add((Component)bottomPanel, "Center");
        bottomContainer.add((Component)statusPanel, "South");
        this.add((Component)bottomContainer, "South");
        this.appendOutput("Bedrock Finder started!");
        this.appendOutput("Type 'help' to see available commands.");
        this.appendOutput("");
        Timer statusTimer = new Timer(1000, e -> this.updateStatus());
        statusTimer.start();
    }

    private void appendOutput(String text) {
        SwingUtilities.invokeLater(() -> {
            this.outputArea.append(text + "\n");
            this.outputArea.setCaretPosition(this.outputArea.getDocument().getLength());
        });
    }

    private void updateStatus() {
        SwingUtilities.invokeLater(() -> {
            this.chunksScannedLabel.setText("Chunks Scanned: " + this.chunksScanned.get());
            this.scanningSpeedLabel.setText("Scanning " + this.scanningSpeed.get() + " per second");
        });
    }

    private void processCommand(String command) {
        String cmd;
        if (command.isEmpty()) {
            return;
        }
        this.appendOutput("> " + command);
        String[] parts = command.split("\\s+");
        switch (cmd = parts[0].toLowerCase()) {
            case "coords": {
                if (this.lastCoordinate != null) {
                    this.appendOutput("Last scanned coordinate: " + this.lastCoordinate);
                    break;
                }
                this.appendOutput("No search in progress.");
                break;
            }
            case "grid": {
                if (parts.length <= 1) break;
                if (parts[1].equals("match")) {
                    if (this.matchGrid != null && !this.matchGrid.isEmpty()) {
                        this.appendOutput("Found match grid:");
                        this.appendOutput(this.matchGrid);
                        break;
                    }
                    this.appendOutput("No match found yet.");
                    break;
                }
                if (!parts[1].equals("possible")) break;
                if (this.possibleGrid != null && !this.possibleGrid.isEmpty()) {
                    this.appendOutput("Current area grid:");
                    this.appendOutput(this.possibleGrid);
                    break;
                }
                this.appendOutput("No search in progress.");
                break;
            }
            case "stop": {
                if (this.isSearching.get()) {
                    this.isSearching.set(false);
                    this.appendOutput("\u25a0 Search stopped completely.");
                    break;
                }
                this.appendOutput("No search in progress.");
                break;
            }
            case "pause": {
                if (this.isSearching.get()) {
                    this.isPaused.set(!this.isPaused.get());
                    this.appendOutput(this.isPaused.get() ? "\u25a0 Search paused." : "\u25a0 Search resumed.");
                    break;
                }
                this.appendOutput("No search in progress.");
                break;
            }
            case "validate": {
                if (parts.length >= 2) {
                    this.validateSeed(parts[1]);
                    break;
                }
                this.appendOutput("Usage: validate <seed>");
                this.appendOutput("Example: validate 111");
                break;
            }
            case "start": {
                SwingUtilities.invokeLater(() -> new PatternSelectionWindow(this));
                break;
            }
            case "info": {
                this.showInfo();
                break;
            }
            case "stats": {
                this.showDetailedStats();
                break;
            }
            case "cache": {
                if (parts.length > 1) {
                    if (parts[1].equals("clear")) {
                        this.clearCache();
                        this.appendOutput("\u25a0 Cache cleared successfully!");
                        break;
                    }
                    if (!parts[1].equals("stats")) break;
                    this.showCacheStats();
                    break;
                }
                this.showCacheStats();
                break;
            }
            case "confirm": {
                if (this.previewParams != null) {
                    this.actuallyStartSearch(this.previewParams);
                    this.previewParams = null;
                    break;
                }
                this.appendOutput("No preview available. Use 'start' command first.");
                break;
            }
            case "download": {
                this.downloadLogs();
                break;
            }
            case "toggle": {
                if (parts.length > 1 && parts[1].equals("stop")) {
                    this.stopOnFirstMatch = !this.stopOnFirstMatch;
                    this.appendOutput("\u25a0 Stop on first match: " + (this.stopOnFirstMatch ? "ENABLED" : "DISABLED"));
                    this.appendOutput("  " + (this.stopOnFirstMatch ? "Search will stop after finding the first match" : "Search will continue to find all matches"));
                    break;
                }
                this.appendOutput("Usage: toggle stop");
                this.appendOutput("Current setting - Stop on first match: " + (this.stopOnFirstMatch ? "ENABLED" : "DISABLED"));
                break;
            }
            case "help": {
                SwingUtilities.invokeLater(() -> new HelpWindow());
                break;
            }
            default: {
                this.appendOutput("\u25a0 Unknown command: " + cmd);
                this.appendOutput("Type 'help' to see available commands.");
            }
        }
        this.appendOutput("");
    }

    private void showHelp() {
        this.appendOutput("AVAILABLE COMMANDS:");
        this.appendOutput("\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550");
        this.appendOutput("coords - Show last scanned coordinate");
        this.appendOutput("grid match - Show found match grid");
        this.appendOutput("grid possible - Show current area grid");
        this.appendOutput("stop - Stop current search completely");
        this.appendOutput("pause - Pause/resume current search");
        this.appendOutput("validate <seed> - Validate seed and show sample");
        this.appendOutput("    Example: validate 111");
        this.appendOutput("start <seed> <coordinates> <stop_on_first> <x:z> - Preview search");
        this.appendOutput("    Single: start 111 1,-63,1,true true 0:0");
        this.appendOutput("    Multiple: start 111 2,-60,2:3,-60,2,true true 0:0");
        this.appendOutput("    Continuous: start 111 1,-63,1,true false 0:0");
        this.appendOutput("confirm - Start the search after preview");
        this.appendOutput("info - Show basic process information");
        this.appendOutput("stats - Show detailed search statistics");
        this.appendOutput("cache - Show cache statistics");
        this.appendOutput("cache clear - Clear bedrock cache");
        this.appendOutput("toggle stop - Toggle stop on first match setting");
        this.appendOutput("download - Save logs to TXT file");
        this.appendOutput("help - Shows this help");
        this.appendOutput("\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550");
        this.appendOutput("TIP: Use 'toggle stop' to switch between finding one or all matches!");
    }

    private void showCoords() {
        this.appendOutput("Last scanned coordinate: " + this.lastCoordinate);
    }

    private void showGridMatch() {
        if (this.matchGrid.isEmpty()) {
            this.appendOutput("No match found yet.");
        } else {
            this.appendOutput("Opening visual grid window for match...");
            SwingUtilities.invokeLater(() -> new GridVisualizationWindow(this.matchGrid, "Match", this.currentX, this.currentZ, this.currentBedrockLayer == 0 ? -60 : -60 - (this.currentBedrockLayer - 1)).setVisible(true));
        }
    }

    private void showGridPossible() {
        if (this.possibleGrid.isEmpty()) {
            this.appendOutput("No possible match found yet.");
        } else {
            this.appendOutput("Opening visual grid window for possible match...");
            SwingUtilities.invokeLater(() -> new GridVisualizationWindow(this.possibleGrid, "Possible", this.currentX, this.currentZ, this.currentBedrockLayer == 0 ? -60 : -60 - (this.currentBedrockLayer - 1)).setVisible(true));
        }
    }

    public void stopSearch() {
        if (this.isSearching.get()) {
            this.isSearching.set(false);
            this.isPaused.set(false);
            if (this.searchThread != null && this.searchThread.isAlive()) {
                this.searchThread.interrupt();
            }
            this.appendOutput("\u25a0 Search cancelled and stopped.");
            this.appendOutput("\u25a0 Use 'download' to download the logs");
            if (this.patternWindow != null) {
                this.patternWindow.setSearchState(false);
            }
        } else {
            this.appendOutput("\u25a0 No search in progress.");
        }
    }

    private void startSearch(String[] parts) {
        if (this.isSearching.get()) {
            this.appendOutput("Search already in progress. Use 'stop' to cancel.");
            return;
        }
        try {
            long previewSeed = Long.parseLong(parts[1]);
            String coordStr = parts[parts.length - 1];
            String[] coords = coordStr.split(":");
            int startX = Integer.parseInt(coords[0]);
            int startZ = Integer.parseInt(coords[1]);
            boolean previewStopOnFirst = Boolean.parseBoolean(parts[parts.length - 2]);
            ArrayList<BedrockBlock> previewPattern = new ArrayList<BedrockBlock>();
            if (parts.length >= 5) {
                String blockPattern = parts[2];
                if (blockPattern.contains(":")) {
                    String[] coordPatterns;
                    String[] stringArray = coordPatterns = blockPattern.split(":");
                    int n = coordPatterns.length;
                    int n2 = 0;
                    while (n2 < n) {
                        String coordPattern = stringArray[n2];
                        String[] coordParts = coordPattern.split(",");
                        if (coordParts.length >= 3) {
                            int x = Integer.parseInt(coordParts[0]);
                            int y = Integer.parseInt(coordParts[1]);
                            int z = Integer.parseInt(coordParts[2]);
                            BedrockBlock.BlockState state = coordParts.length > 3 ? (Boolean.parseBoolean(coordParts[3]) ? BedrockBlock.BlockState.SUSPECT : BedrockBlock.BlockState.BLUE) : BedrockBlock.BlockState.SUSPECT;
                            previewPattern.add(new BedrockBlock(x, y, z, state));
                        }
                        ++n2;
                    }
                } else {
                    previewPattern.add(new BedrockBlock(blockPattern));
                }
            }
            if (previewPattern.isEmpty()) {
                this.appendOutput("Error: No blocks specified.");
                return;
            }
            BedrockReader previewReader = new BedrockReader(previewSeed, BedrockReader.BedrockType.BEDROCK_FLOOR);
            this.appendOutput("\u25a0 SEARCH PREVIEW:");
            this.appendOutput("\u25a0 Seed: " + previewSeed);
            this.appendOutput("\u25a0 Pattern: " + previewPattern.size() + " blocks");
            this.appendOutput("\u25a0 Stop on first match: " + previewStopOnFirst);
            this.appendOutput("\u25a0 Starting position: " + startX + ":" + startZ);
            this.appendOutput("");
            String previewGrid = this.generatePreviewGrid(startX, startZ, ((BedrockBlock)previewPattern.get((int)0)).y, previewReader, previewPattern);
            this.appendOutput("Preview grid showing expected pattern:");
            this.appendOutput(previewGrid);
            this.appendOutput("");
            this.appendOutput("Use \"confirm\" to start the program");
            this.previewParams = parts;
        }
        catch (Exception e) {
            this.appendOutput("Error creating preview: " + e.getMessage());
        }
    }

    private void actuallyStartSearch(String[] parts) {
        try {
            this.currentSeed = Long.parseLong(parts[1]);
            int startX = 0;
            int startZ = 0;
            try {
                startX = Integer.parseInt(this.xStartField.getText().trim());
                startZ = Integer.parseInt(this.zStartField.getText().trim());
            }
            catch (NumberFormatException e) {
                this.appendOutput("\u25a0 Invalid starting position values. Using default (0, 0).");
                startX = 0;
                startZ = 0;
                this.xStartField.setText("0");
                this.zStartField.setText("0");
            }
            this.stopOnFirstMatch = Boolean.parseBoolean(parts[parts.length - 2]);
            this.currentPattern = new ArrayList<BedrockBlock>();
            if (parts.length >= 5) {
                String blockPattern = parts[2];
                if (blockPattern.contains(":")) {
                    String[] coordPatterns;
                    String[] stringArray = coordPatterns = blockPattern.split(":");
                    int n = coordPatterns.length;
                    int n2 = 0;
                    while (n2 < n) {
                        String coordPattern = stringArray[n2];
                        String[] coordParts = coordPattern.split(",");
                        if (coordParts.length >= 3) {
                            int x = Integer.parseInt(coordParts[0]);
                            int y = Integer.parseInt(coordParts[1]);
                            int z = Integer.parseInt(coordParts[2]);
                            BedrockBlock.BlockState state = coordParts.length > 3 ? (Boolean.parseBoolean(coordParts[3]) ? BedrockBlock.BlockState.SUSPECT : BedrockBlock.BlockState.BLUE) : BedrockBlock.BlockState.SUSPECT;
                            this.currentPattern.add(new BedrockBlock(x, y, z, state));
                        }
                        ++n2;
                    }
                } else {
                    this.currentPattern.add(new BedrockBlock(blockPattern));
                }
            }
            this.bedrockReader = new BedrockReader(this.currentSeed, BedrockReader.BedrockType.BEDROCK_FLOOR);
            this.appendOutput("\u25a0 Starting search...");
            this.appendOutput("\u25a0 Seed: " + this.currentSeed);
            this.appendOutput("\u25a0 Pattern: " + this.currentPattern.size() + " blocks");
            this.appendOutput("\u25a0 Stop on first match: " + this.stopOnFirstMatch);
            this.appendOutput("\u25a0 Starting position: " + startX + ":" + startZ);
            this.chunksScanned.set(0L);
            this.scanningSpeed.set(0L);
            this.currentX = startX;
            this.currentZ = startZ;
            this.isSearching.set(true);
            this.isPaused.set(false);
            this.matchGrid = "";
            this.possibleGrid = "";
            this.matchesFound.set(0);
            this.clearCache();
            this.searchThread = new Thread(this::performSearch);
            this.searchThread.start();
            if (this.patternWindow != null) {
                this.patternWindow.setSearchState(true);
            }
        }
        catch (Exception e) {
            this.appendOutput("Error starting search: " + e.getMessage());
        }
    }

    private void performSearch() {
        this.appendOutput("■ DEBUG: performSearch method started");
        
        long lastSpeedUpdate = System.currentTimeMillis();
        long lastChunkCount = 0L;
        this.clearCache();
        this.hiddenLogs.clear();
        
        this.appendOutput("■ DEBUG: Initialization complete, starting search output");
        this.appendOutput("🚀 FAST BEDROCK SEARCH STARTED!");
        this.appendOutput("📍 Starting from: " + this.currentX + ":" + this.currentZ);
        this.appendOutput("🎯 Pattern: " + this.currentPattern.size() + " blocks");
        this.appendOutput("🌍 Bedrock layer: " + (String)(this.currentBedrockLayer == 0 ? "All (Y -60 to -63)" : "Layer " + this.currentBedrockLayer + " (Y " + (-60 - (this.currentBedrockLayer - 1)) + ")"));
        try {
            try {
                int spiralX = this.currentX;
                int spiralZ = this.currentZ;
                int direction = 0;
                int steps = 1;
                int stepCount = 0;
                long searchStartTime = System.currentTimeMillis();
                this.matchesFound.set(0);
                this.chunksScanned.set(0L);
                while (this.isSearching.get()) {
                    long currentChunksScanned;
                    if (this.isPaused.get()) {
                        Thread.sleep(100L);
                        continue;
                    }
                    this.currentX = spiralX;
                    this.currentZ = spiralZ;
                    this.lastCoordinate = "X:" + this.currentX + " Z:" + this.currentZ;
                    int y = this.currentBedrockLayer == 0 ? -62 : -60 - (this.currentBedrockLayer - 1);
                    double similarity = this.calculatePartialMatchScore(this.currentX, this.currentZ, y);
                    if (similarity >= 1.0) {
                        int currentMatches = this.matchesFound.incrementAndGet();
                        this.matchGrid = this.generateMatchGrid(this.currentX, this.currentZ, y);
                        this.appendOutput("\u2705 PERFECT MATCH #" + currentMatches + " FOUND!");
                        this.appendOutput("\ud83d\udccd Coordinates: X:" + this.currentX + " Z:" + this.currentZ);
                        this.appendOutput("\ud83c\udf0d Y Level: " + y);
                        this.appendOutput("\ud83d\udcca Similarity: 100%");
                        this.appendOutput("\ud83d\udcca Chunks scanned: " + this.chunksScanned.get());
                        this.appendOutput("\u23f1\ufe0f Time: " + (System.currentTimeMillis() - searchStartTime) / 1000L + "s");
                        SystemNotification.showPatternFoundNotification();
                        int finalX = this.currentX;
                        int finalZ = this.currentZ;
                        int finalY = y;
                        String finalMatchGrid = this.matchGrid;
                        SwingUtilities.invokeLater(() -> new GridVisualizationWindow(finalMatchGrid, "Perfect Match #" + currentMatches, finalX, finalZ, finalY).setVisible(true));
                        if (this.patternWindow != null) {
                            SwingUtilities.invokeLater(() -> {
                                this.patternWindow.addConsoleMessage("\u2705 PERFECT MATCH #" + currentMatches + " FOUND!");
                                this.patternWindow.addConsoleMessage("\ud83d\udccd Coordinates: X:" + this.currentX + " Z:" + this.currentZ);
                                this.patternWindow.addConsoleMessage("\ud83c\udf0d Y Level: " + y);
                                this.patternWindow.addConsoleMessage("\ud83d\udcca Similarity: 100%");
                                this.patternWindow.addConsoleMessage("\ud83c\udfaf Grid visualization window opened automatically!");
                            });
                        }
                        this.appendOutput("\ud83c\udfaf Search completed - Perfect match found!");
                        break;
                    }
                    if (similarity >= 0.95) {
                        int currentMatches = this.matchesFound.incrementAndGet();
                        if (similarity == 1.0) {
                            this.appendOutput("\ud83c\udfaf PERFECT MATCH #" + currentMatches + " FOUND!");
                        } else {
                            this.appendOutput("\ud83d\udfe1 HIGH SIMILARITY MATCH #" + currentMatches + " FOUND!");
                        }
                        this.appendOutput("\ud83d\udccd Coordinates: X:" + this.currentX + " Z:" + this.currentZ);
                        this.appendOutput("\ud83c\udf0d Y Level: " + y);
                        this.appendOutput("\ud83d\udcca Similarity: " + String.format("%.1f%%", similarity * 100.0));
                        if (this.patternWindow != null) {
                            SwingUtilities.invokeLater(() -> {
                                if (similarity == 1.0) {
                                    this.patternWindow.addConsoleMessage("\ud83c\udfaf PERFECT MATCH #" + currentMatches + " FOUND!");
                                } else {
                                    this.patternWindow.addConsoleMessage("\ud83d\udfe1 HIGH SIMILARITY MATCH #" + currentMatches + " FOUND!");
                                }
                                this.patternWindow.addConsoleMessage("\ud83d\udccd Coordinates: X:" + this.currentX + " Z:" + this.currentZ);
                                this.patternWindow.addConsoleMessage("\ud83c\udf0d Y Level: " + y);
                                this.patternWindow.addConsoleMessage("\ud83d\udcca Similarity: " + String.format("%.1f%%", similarity * 100.0));
                            });
                        }
                        if (this.stopOnFirstMatch && similarity == 1.0) {
                            this.appendOutput("\ud83c\udfaf Search completed (perfect match found)");
                            break;
                        }
                    } else if (similarity >= 0.85) {
                        this.mediumSimilarityMatches.add(new SimilarityMatch(this.currentX, this.currentZ, y, similarity));
                        this.appendOutput("\ud83d\udfe0 Medium similarity: X:" + this.currentX + " Z:" + this.currentZ + " (" + String.format("%.1f%%", similarity * 100.0) + ")");
                    }
                    if ((currentChunksScanned = this.chunksScanned.incrementAndGet()) >= (long)this.maxChunks) {
                        this.appendOutput("\ud83d\uded1 Maximum chunks limit reached: " + this.maxChunks);
                        this.appendOutput("\ud83c\udfc1 Search stopped due to chunk limit.");
                        break;
                    }
                    long currentTime = System.currentTimeMillis();
                    if (currentTime - lastSpeedUpdate >= 1000L) {
                        long currentChunks = this.chunksScanned.get();
                        this.scanningSpeed.set(currentChunks - lastChunkCount);
                        lastChunkCount = currentChunks;
                        lastSpeedUpdate = currentTime;
                        SwingUtilities.invokeLater(this::updateStatus);
                        if ((currentTime - searchStartTime) % 30000L < 1000L) {
                            long searchTime = (currentTime - searchStartTime) / 1000L;
                            this.appendOutput("\ud83d\udcc8 Progress: " + currentChunks + " chunks | " + this.scanningSpeed.get() + "/s | " + searchTime + "s");
                        }
                    }
                    switch (direction) {
                        case 0: {
                            ++spiralX;
                            break;
                        }
                        case 1: {
                            ++spiralZ;
                            break;
                        }
                        case 2: {
                            --spiralX;
                            break;
                        }
                        case 3: {
                            --spiralZ;
                        }
                    }
                    if (++stepCount >= steps) {
                        stepCount = 0;
                        if ((direction = (direction + 1) % 4) % 2 == 0) {
                            ++steps;
                        }
                    }
                    Thread.sleep(1L);
                }
                long totalTime = (System.currentTimeMillis() - searchStartTime) / 1000L;
                this.appendOutput("\ud83c\udfc1 SEARCH COMPLETED!");
                this.appendOutput("\ud83d\udcca Final stats: " + this.matchesFound.get() + " matches found | " + this.chunksScanned.get() + " chunks scanned | " + totalTime + "s");
                if (this.patternWindow != null && !this.mediumSimilarityMatches.isEmpty()) {
                    SwingUtilities.invokeLater(() -> {
                        this.patternWindow.updateMediumSimilarityMatches(this.mediumSimilarityMatches);
                        this.patternWindow.addConsoleMessage("\ud83d\udccb Found " + this.mediumSimilarityMatches.size() + " medium similarity matches (85-94%)");
                    });
                }
            }
            catch (InterruptedException e) {
                this.appendOutput("\u23f8\ufe0f Search interrupted.");
                this.isSearching.set(false);
                this.isPaused.set(false);
                this.scanningSpeed.set(0L);
                if (this.patternWindow != null) {
                    this.patternWindow.setSearchState(false);
                }
            }
            catch (Exception e) {
                this.appendOutput("\u274c Error during search: " + e.getMessage());
                e.printStackTrace();
                this.isSearching.set(false);
                this.isPaused.set(false);
                this.scanningSpeed.set(0L);
                if (this.patternWindow != null) {
                    this.patternWindow.setSearchState(false);
                }
            }
        }
        finally {
            this.isSearching.set(false);
            this.isPaused.set(false);
            this.scanningSpeed.set(0L);
            if (this.patternWindow != null) {
                this.patternWindow.setSearchState(false);
            }
        }
    }

    private boolean checkBedrockFormation(int centerX, int centerZ) {
        for (BedrockBlock block : this.currentPattern) {
            int x = centerX + block.x;
            int z = centerZ + block.z;
            if (this.currentBedrockLayer == 0) {
                boolean foundMatch = false;
                int layer = 0;
                while (layer < 4) {
                    int y = -60 - layer;
                    boolean actualBedrock = this.getCachedBedrock(x, y, z);
                    if (actualBedrock == block.shouldBeBedrock()) {
                        foundMatch = true;
                        break;
                    }
                    ++layer;
                }
                if (foundMatch) continue;
                return false;
            }
            int y = -60 - (this.currentBedrockLayer - 1);
            boolean actualBedrock = this.getCachedBedrock(x, y, z);
            if (actualBedrock == block.shouldBeBedrock()) continue;
            return false;
        }
        return true;
    }

    private boolean getCachedBedrock(int x, int y, int z) {
        String key = x + "," + y + "," + z;
        Boolean cached = this.bedrockCache.get(key);
        if (cached != null) {
            this.cacheHits.incrementAndGet();
            return cached;
        }
        this.cacheMisses.incrementAndGet();
        boolean result = this.bedrockReader.isBedrock(x, y, z);
        if (this.bedrockCache.size() >= 10000) {
            this.bedrockCache.clear();
        }
        this.bedrockCache.put(key, result);
        return result;
    }

    private void clearCache() {
        this.bedrockCache.clear();
        this.cacheHits.set(0L);
        this.cacheMisses.set(0L);
    }

    private String generateGrid(int centerX, int centerZ, int y) {
        StringBuilder grid = new StringBuilder();
        int z = centerZ - 8;
        while (z <= centerZ + 7) {
            int x = centerX - 8;
            while (x <= centerX + 7) {
                boolean isBedrock = this.getCachedBedrock(x, y, z);
                grid.append(isBedrock ? "\u25a0" : "#");
                ++x;
            }
            grid.append("\n");
            ++z;
        }
        return grid.toString();
    }

    private String generateMatchGrid(int centerX, int centerZ, int y) {
        StringBuilder grid = new StringBuilder();
        int z = centerZ - 8;
        while (z <= centerZ + 7) {
            int x = centerX - 8;
            while (x <= centerX + 7) {
                boolean isBedrock = this.getCachedBedrock(x, y, z);
                if (!isBedrock) {
                    grid.append(".");
                } else {
                    boolean isPatternBedrock = false;
                    for (BedrockBlock block : this.currentPattern) {
                        int patternX = centerX + block.x;
                        int patternZ = centerZ + block.z;
                        if (x != patternX || z != patternZ) continue;
                        isPatternBedrock = true;
                        break;
                    }
                    if (isPatternBedrock) {
                        grid.append("M");
                    } else {
                        grid.append("B");
                    }
                }
                ++x;
            }
            grid.append("\n");
            ++z;
        }
        return grid.toString();
    }

    private String generatePreviewGrid(int centerX, int centerZ, int y, BedrockReader reader, List<BedrockBlock> pattern) {
        StringBuilder grid = new StringBuilder();
        int row = 16;
        while (row >= 1) {
            if (row < 10) {
                grid.append(" ").append(row).append("  |");
            } else {
                grid.append(row).append(" |");
            }
            int col = 1;
            while (col <= 16) {
                int relativeX = col - 8;
                int relativeZ = row - 8;
                boolean isPatternPosition = false;
                boolean shouldBeBedrockInPattern = false;
                for (BedrockBlock block : pattern) {
                    if (block.x != relativeX || block.z != relativeZ || block.y != y) continue;
                    isPatternPosition = true;
                    shouldBeBedrockInPattern = block.shouldBeBedrock();
                    break;
                }
                if (isPatternPosition) {
                    grid.append(shouldBeBedrockInPattern ? "\u25a0" : "#");
                } else {
                    grid.append("#");
                }
                if (col < 16) {
                    grid.append("  ");
                }
                ++col;
            }
            grid.append("\n");
            --row;
        }
        grid.append("   ");
        int col = 1;
        while (col <= 16) {
            if (col < 10) {
                grid.append(" ").append(col);
            } else {
                grid.append(col);
            }
            if (col < 16) {
                grid.append(" ");
            }
            ++col;
        }
        grid.append("\n");
        return grid.toString();
    }

    private void showInfo() {
        this.appendOutput("\u25a0 PROCESS INFORMATION:");
        this.appendOutput("\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550");
        this.appendOutput("\u25a0 Search active: " + this.isSearching.get());
        this.appendOutput("\u25a0 Search paused: " + this.isPaused.get());
        this.appendOutput("\u25a0 Current seed: " + String.valueOf(this.currentSeed != 0L ? Long.valueOf(this.currentSeed) : "None"));
        this.appendOutput("\u25a0 Last coordinate: " + (String)(this.currentX != 0 || this.currentZ != 0 ? "(" + this.currentX + ", " + this.currentZ + ")" : "None"));
        this.appendOutput("\u25a0 Chunks scanned: " + this.chunksScanned.get());
        this.appendOutput("\u25a0 Current speed: " + this.scanningSpeed.get() + " chunks/second");
        this.appendOutput("\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550");
    }

    private void validateSeed(String seedStr) {
        try {
            long seed = Long.parseLong(seedStr);
            this.appendOutput("\u25a0 Validating seed: " + seed);
            BedrockReader testReader = new BedrockReader(seed, BedrockReader.BedrockType.BEDROCK_FLOOR);
            int validPoints = 0;
            int totalTests = 10;
            int i = 0;
            while (i < totalTests) {
                int x = i * 16;
                int z = i * 16;
                boolean bedrock = testReader.isBedrock(x, -64, z);
                if (bedrock || !bedrock) {
                    ++validPoints;
                }
                ++i;
            }
            if (validPoints == totalTests) {
                this.appendOutput("\u25a0 Seed " + seed + " is VALID!");
                this.appendOutput("\u25a0 Bedrock generation working correctly");
                this.appendOutput("\u25a0 Sample bedrock at Y=-64:");
                StringBuilder sample = new StringBuilder();
                int z = 0;
                while (z < 5) {
                    int x = 0;
                    while (x < 10) {
                        boolean isBedrock = testReader.isBedrock(x, -64, z);
                        sample.append(isBedrock ? "\ud83d\udfe9" : "\ud83d\udfe5");
                        ++x;
                    }
                    sample.append("\n");
                    ++z;
                }
                this.appendOutput(sample.toString());
            } else {
                this.appendOutput("\u25a0 Seed validation failed!");
                this.appendOutput("\u25a0 RNG may not be working correctly");
            }
        }
        catch (NumberFormatException e) {
            this.appendOutput("\u25a0 Invalid seed format: " + seedStr);
            this.appendOutput("\u25a0 Seeds must be numeric (e.g., 111, -123456789)");
        }
        catch (Exception e) {
            this.appendOutput("\u25a0 Error validating seed: " + e.getMessage());
        }
    }

    private void showDetailedStats() {
        long totalRequests;
        if (!this.isSearching.get()) {
            this.appendOutput("\u25a0 No active search - showing general statistics");
            this.appendOutput("\u25a0 Memory usage: " + (Runtime.getRuntime().totalMemory() - Runtime.getRuntime().freeMemory()) / 1024L / 1024L + " MB");
            this.appendOutput("\u25a0 Available processors: " + Runtime.getRuntime().availableProcessors());
            return;
        }
        this.appendOutput("\u25a0 DETAILED SEARCH STATISTICS");
        this.appendOutput("\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550");
        this.appendOutput("\u25a0 Current seed: " + this.currentSeed);
        this.appendOutput("\u25a0 Current position: " + this.lastCoordinate);
        this.appendOutput("\u25a0 Chunks scanned: " + this.chunksScanned.get());
        this.appendOutput("\u25a0 Current speed: " + this.scanningSpeed.get() + " chunks/second");
        this.appendOutput("\u25a0 Status: " + (this.isPaused.get() ? "PAUSED" : "RUNNING"));
        if (this.currentPattern != null && !this.currentPattern.isEmpty()) {
            this.appendOutput("\u25a0 Pattern details:");
            int i = 0;
            while (i < this.currentPattern.size()) {
                BedrockBlock block = this.currentPattern.get(i);
                this.appendOutput("  Block " + (i + 1) + ": (" + block.x + "," + block.y + "," + block.z + ") = " + (block.shouldBeBedrock() ? "BEDROCK" : "NOT BEDROCK"));
                ++i;
            }
        }
        this.appendOutput("\u25a0 Search settings:");
        this.appendOutput("  Stop on first match: " + (this.stopOnFirstMatch ? "YES" : "NO"));
        this.appendOutput("  Search type: INFINITE SPIRAL");
        long totalMemory = Runtime.getRuntime().totalMemory();
        long freeMemory = Runtime.getRuntime().freeMemory();
        long usedMemory = totalMemory - freeMemory;
        this.appendOutput("\u25a0 System performance:");
        this.appendOutput("  Memory used: " + usedMemory / 1024L / 1024L + " MB");
        this.appendOutput("  Memory total: " + totalMemory / 1024L / 1024L + " MB");
        this.appendOutput("  CPU cores: " + Runtime.getRuntime().availableProcessors());
        if (this.chunksScanned.get() > 0L) {
            double radius = Math.sqrt((double)this.chunksScanned.get() / Math.PI);
            double areaKm = (double)(this.chunksScanned.get() * 16L * 16L) / 1000000.0;
            this.appendOutput("\u25a0 Area coverage:");
            this.appendOutput("  Approximate radius: " + String.format("%.1f", radius) + " chunks");
            this.appendOutput("  Area covered: " + String.format("%.2f", areaKm) + " km\u00b2");
            this.appendOutput("  Blocks checked: " + this.chunksScanned.get() * 256L + " (estimated)");
        }
        if ((totalRequests = this.cacheHits.get() + this.cacheMisses.get()) > 0L) {
            double hitRate = (double)this.cacheHits.get() / (double)totalRequests * 100.0;
            this.appendOutput("\u25a0 Cache performance:");
            this.appendOutput("  Cache size: " + this.bedrockCache.size() + " / 10000");
            this.appendOutput("  Hit rate: " + String.format("%.1f", hitRate) + "%");
            this.appendOutput("  Total requests: " + totalRequests);
        }
        this.appendOutput("\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550");
    }

    private void showCacheStats() {
        this.appendOutput("\u25a0 CACHE STATISTICS:");
        this.appendOutput("\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550");
        if (this.bedrockCache == null) {
            this.appendOutput("\u25a0 Cache not initialized");
            return;
        }
        int cacheSize = this.bedrockCache.size();
        long totalRequests = this.cacheHits.get() + this.cacheMisses.get();
        double hitRate = totalRequests > 0L ? (double)this.cacheHits.get() * 100.0 / (double)totalRequests : 0.0;
        this.appendOutput("\u25a0 Cache size: " + cacheSize + " / 10000 entries");
        this.appendOutput("\u25a0 Cache hits: " + this.cacheHits.get());
        this.appendOutput("\u25a0 Cache misses: " + this.cacheMisses.get());
        this.appendOutput("\u25a0 Hit rate: " + String.format("%.1f", hitRate) + "%");
        this.appendOutput("\u25a0 Total requests: " + totalRequests);
        long estimatedMemory = cacheSize * 32;
        this.appendOutput("\u25a0 Estimated memory: ~" + estimatedMemory + " bytes");
        if (hitRate > 80.0) {
            this.appendOutput("\u25a0 Excellent cache performance!");
        } else if (hitRate > 60.0) {
            this.appendOutput("\u25a0 Good cache performance");
        } else if (totalRequests > 0L) {
            this.appendOutput("\u25a0 Poor cache performance - consider clearing cache");
        }
        this.appendOutput("\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550");
    }

    private void downloadLogs() {
        block18: {
            try {
                if (this.hiddenLogs.isEmpty()) {
                    this.appendOutput("\u25a0 No hidden logs available to download.");
                    this.appendOutput("\u25a0 Hidden logs are generated during search operations.");
                    return;
                }
                JFileChooser fileChooser = new JFileChooser();
                fileChooser.setDialogTitle("Save Hidden System Logs");
                String timestamp = LocalDateTime.now().format(DateTimeFormatter.ofPattern("yyyy-MM-dd_HH-mm-ss"));
                String defaultFilename = "bedrock_finder_hidden_logs_" + timestamp + ".txt";
                fileChooser.setSelectedFile(new File(defaultFilename));
                FileNameExtensionFilter filter = new FileNameExtensionFilter("Text Files (*.txt)", "txt");
                fileChooser.setFileFilter(filter);
                int userSelection = fileChooser.showSaveDialog(this);
                if (userSelection == 0) {
                    File fileToSave = fileChooser.getSelectedFile();
                    Object filePath = fileToSave.getAbsolutePath();
                    if (!((String)filePath).toLowerCase().endsWith(".txt")) {
                        filePath = (String)filePath + ".txt";
                        fileToSave = new File((String)filePath);
                    }
                    try {
                        Throwable throwable = null;
                        Object var9_12 = null;
                        try (FileWriter writer = new FileWriter(fileToSave);){
                            writer.write("Minecraft Bedrock Formation Finder - Hidden System Logs\n");
                            writer.write("Generated: " + LocalDateTime.now().format(DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss")) + "\n");
                            writer.write("\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\n\n");
                            if (this.currentSeed != 0L) {
                                writer.write("SESSION INFORMATION:\n");
                                writer.write("Seed: " + this.currentSeed + "\n");
                                writer.write("Search Status: " + (this.isSearching.get() ? (this.isPaused.get() ? "Paused" : "Running") : "Stopped") + "\n");
                                writer.write("Chunks Scanned: " + this.chunksScanned.get() + "\n");
                                writer.write("Current Position: " + (String)(this.currentX != 0 || this.currentZ != 0 ? "(" + this.currentX + ", " + this.currentZ + ")" : "None") + "\n");
                                writer.write("Matches Found: " + this.matchesFound.get() + "\n");
                                writer.write("Cache Hits: " + this.cacheHits.get() + "\n");
                                writer.write("Cache Misses: " + this.cacheMisses.get() + "\n");
                                writer.write("Search Algorithm: Simplified Direct Search\n");
                                writer.write("Detailed Logging: " + (this.enableDetailedLogging ? "Enabled" : "Disabled") + "\n");
                                writer.write("\n");
                            }
                            writer.write("HIDDEN SYSTEM LOGS (" + this.hiddenLogs.size() + " entries):\n");
                            writer.write("\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\n");
                            for (String logEntry : this.hiddenLogs) {
                                writer.write(logEntry + "\n");
                            }
                            this.appendOutput("\u25a0 Hidden logs saved successfully to: " + fileToSave.getAbsolutePath());
                            this.appendOutput("\u25a0 File size: " + String.format("%.2f", (double)fileToSave.length() / 1024.0) + " KB");
                            this.appendOutput("\u25a0 Total log entries: " + this.hiddenLogs.size());
                            break block18;
                        }
                        catch (Throwable throwable2) {
                            this.appendOutput("■ Error writing to file: " + throwable2.getMessage());
                        }
                    }
                    catch (Exception e) {
                        this.appendOutput("■ Error during file operation: " + e.getMessage());
                    }
                    break block18;
                }
                this.appendOutput("\u25a0 Download cancelled by user.");
            }
            catch (Exception e) {
                this.appendOutput("\u25a0 Error during download: " + e.getMessage());
            }
        }
    }

    public void startSearchFromGUI(long seed, List<BedrockBlock> pattern, int bedrockLayer, boolean stopOnFirstMatch, int minX, int maxX, int minZ, int maxZ, int maxChunks, PatternSelectionWindow patternWindow) {
        this.patternWindow = patternWindow;
        this.appendOutput("■ DEBUG: startSearchFromGUI called with seed: " + seed);
        
        if (this.isSearching.get()) {
            this.appendOutput("Search already in progress. Use 'stop' to cancel.");
            return;
        }
        try {
            int startX = 0;
            int startZ = 0;
            try {
                startX = Integer.parseInt(this.xStartField.getText().trim());
                startZ = Integer.parseInt(this.zStartField.getText().trim());
            }
            catch (NumberFormatException e) {
                this.appendOutput("\u25a0 Invalid starting position values. Using default (0, 0).");
                startX = 0;
                startZ = 0;
                this.xStartField.setText("0");
                this.zStartField.setText("0");
            }
            this.currentSeed = seed;
            this.currentPattern = new ArrayList<BedrockBlock>(pattern);
            this.currentBedrockLayer = bedrockLayer;
            this.currentX = startX;
            this.currentZ = startZ;
            this.stopOnFirstMatch = stopOnFirstMatch;
            this.maxChunks = maxChunks;
            this.appendOutput("■ DEBUG: Creating BedrockReader...");
            this.bedrockReader = new BedrockReader(this.currentSeed, BedrockReader.BedrockType.BEDROCK_FLOOR);
            this.appendOutput("■ DEBUG: BedrockReader created successfully");
            
            this.appendOutput("■ Starting improved search...");
            this.appendOutput("■ Seed: " + this.currentSeed);
            this.appendOutput("■ Pattern: " + this.currentPattern.size() + " blocks");
            this.appendOutput("■ Bedrock layer: " + (String)(bedrockLayer == 0 ? "All layers (Y -60 to -63)" : "Layer " + bedrockLayer + " (Y " + (-60 - (bedrockLayer - 1)) + ")"));
            this.appendOutput("■ Stop on first match: " + this.stopOnFirstMatch);
            this.appendOutput("■ Search area: X(" + minX + " to " + maxX + ") Z(" + minZ + " to " + maxZ + ")");
            this.appendOutput("■ Max chunks to scan: " + this.maxChunks);
            this.appendOutput("■ Starting position: " + minX + ":" + minZ);
            
            this.appendOutput("■ DEBUG: Initializing search state...");
            this.chunksScanned.set(0L);
            this.scanningSpeed.set(0L);
            this.isSearching.set(true);
            this.isPaused.set(false);
            this.matchGrid = "";
            this.possibleGrid = "";
            this.matchesFound.set(0);
            this.mediumSimilarityMatches.clear();
            this.clearCache();
            
            this.appendOutput("■ DEBUG: Creating and starting search thread...");
            this.searchThread = new Thread(this::performSearch);
            this.searchThread.start();
            this.appendOutput("■ DEBUG: Search thread started successfully!");
        }
        catch (Exception e) {
            this.appendOutput("Error starting search: " + e.getMessage());
        }
    }

    public void addOutput(String text) {
        this.appendOutput(text);
    }

    public void processConfirmation(String response) {
        this.processCommand(response);
    }

    private boolean checkFormationSimilar(int centerX, int centerZ, int bedrockLayer) {
        if (bedrockLayer == 0) {
            int layer = -60;
            while (layer >= -63) {
                if (this.checkFormationWithRotations(centerX, centerZ, layer)) {
                    return true;
                }
                --layer;
            }
            return false;
        }
        int targetY = -60 - (bedrockLayer - 1);
        return this.checkFormationWithRotations(centerX, centerZ, targetY);
    }

    private boolean checkFormationWithRotations(int centerX, int centerZ, int y) {
        ArrayList<BedrockBlock> originalPattern = new ArrayList<BedrockBlock>(this.currentPattern);
        int rotation = 0;
        while (rotation < 4) {
            if (this.checkFormationWithTolerance(centerX, centerZ, y, this.currentPattern)) {
                return true;
            }
            this.rotatePattern90Degrees();
            ++rotation;
        }
        this.currentPattern = originalPattern;
        return false;
    }

    private void rotatePattern90Degrees() {
        for (BedrockBlock block : this.currentPattern) {
            int newX = -block.z;
            int newZ = block.x;
            block.x = newX;
            block.z = newZ;
        }
    }

    private boolean checkFormationWithTolerance(int centerX, int centerZ, int y, List<BedrockBlock> pattern) {
        int totalBlocks = pattern.size();
        int matchingBlocks = 0;
        int tolerance = Math.max(1, totalBlocks / 4);
        for (BedrockBlock block : pattern) {
            boolean actualBedrock = this.getCachedBedrock(centerX + block.x, y, centerZ + block.z);
            if (actualBedrock != block.shouldBeBedrock()) continue;
            ++matchingBlocks;
        }
        return totalBlocks - matchingBlocks <= tolerance;
    }

    private MatchResult generateMatchResult(int centerX, int centerZ, int y) {
        int gridSize = 16;
        int halfSize = gridSize / 2;
        boolean[][] bedrockGrid = new boolean[gridSize][gridSize];
        boolean[][] patternGrid = new boolean[gridSize][gridSize];
        boolean[][] matchGrid = new boolean[gridSize][gridSize];
        int i = 0;
        while (i < gridSize) {
            int j = 0;
            while (j < gridSize) {
                int worldX = centerX + (i - halfSize);
                int worldZ = centerZ + (j - halfSize);
                bedrockGrid[i][j] = this.getCachedBedrock(worldX, y, worldZ);
                ++j;
            }
            ++i;
        }
        for (BedrockBlock block : this.currentPattern) {
            int gridX = halfSize + block.x;
            int gridZ = halfSize + block.z;
            if (gridX < 0 || gridX >= gridSize || gridZ < 0 || gridZ >= gridSize) continue;
            patternGrid[gridX][gridZ] = true;
            boolean actualBedrock = this.getCachedBedrock(centerX + block.x, y, centerZ + block.z);
            boolean bl = matchGrid[gridX][gridZ] = actualBedrock == block.shouldBeBedrock();
        }
        return new MatchResult(centerX, centerZ, y, bedrockGrid, patternGrid, matchGrid);
    }

    private double calculatePartialMatchScore(int centerX, int centerZ, int y) {
        if (this.currentPattern == null || this.currentPattern.isEmpty()) {
            return 0.0;
        }
        int totalBlocks = this.currentPattern.size();
        int matchingBlocks = 0;
        for (BedrockBlock block : this.currentPattern) {
            int worldX = centerX + block.x;
            int worldZ = centerZ + block.z;
            boolean actualBedrock = this.getCachedBedrock(worldX, y, worldZ);
            if (actualBedrock != block.shouldBeBedrock()) continue;
            ++matchingBlocks;
        }
        return (double)matchingBlocks / (double)totalBlocks;
    }

    private void logDetailed(String message) {
        if (this.enableDetailedLogging) {
            String timestamp = LocalDateTime.now().format(DateTimeFormatter.ofPattern("HH:mm:ss.SSS"));
            String logEntry = "[" + timestamp + "] " + message;
            this.hiddenLogs.add(logEntry);
            if (this.hiddenLogs.size() > 10000) {
                this.hiddenLogs.remove(0);
            }
        }
    }

    private void addTextFieldEffects(final JTextField textField) {
        textField.addMouseListener(new MouseAdapter(){

            @Override
            public void mouseEntered(MouseEvent e) {
                textField.setCursor(BedrockFinderGUI.this.textCursor);
                BedrockFinderGUI.this.playHoverSound();
            }

            @Override
            public void mouseExited(MouseEvent e) {
                textField.setCursor(BedrockFinderGUI.this.normalCursor);
            }
        });
    }

    private void playClickSound() {
        try {
            if (this.clickSound != null) {
                if (this.clickSound.isControlSupported(FloatControl.Type.MASTER_GAIN)) {
                    FloatControl gainControl = (FloatControl)this.clickSound.getControl(FloatControl.Type.MASTER_GAIN);
                    gainControl.setValue(gainControl.getMaximum());
                }
                this.clickSound.setFramePosition(0);
                this.clickSound.start();
            }
        }
        catch (Exception exception) {
            // empty catch block
        }
    }

    private void playHoverSound() {
        try {
            if (this.hoverSound != null) {
                if (this.hoverSound.isControlSupported(FloatControl.Type.MASTER_GAIN)) {
                    FloatControl gainControl = (FloatControl)this.hoverSound.getControl(FloatControl.Type.MASTER_GAIN);
                    gainControl.setValue(gainControl.getMaximum());
                }
                this.hoverSound.setFramePosition(0);
                this.hoverSound.start();
            }
        }
        catch (Exception exception) {
            // empty catch block
        }
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            BedrockFinderGUI bedrockGUI = new BedrockFinderGUI();
            new PatternSelectionWindow(bedrockGUI).setVisible(true);
        });
    }

    public static class MatchResult {
        public final int centerX;
        public final int centerZ;
        public final int y;
        public final boolean[][] bedrockGrid;
        public final boolean[][] patternGrid;
        public final boolean[][] matchGrid;

        public MatchResult(int centerX, int centerZ, int y, boolean[][] bedrockGrid, boolean[][] patternGrid, boolean[][] matchGrid) {
            this.centerX = centerX;
            this.centerZ = centerZ;
            this.y = y;
            this.bedrockGrid = bedrockGrid;
            this.patternGrid = patternGrid;
            this.matchGrid = matchGrid;
        }
    }

    public static class SimilarityMatch {
        public final int centerX;
        public final int centerZ;
        public final int y;
        public final double similarity;

        public SimilarityMatch(int centerX, int centerZ, int y, double similarity) {
            this.centerX = centerX;
            this.centerZ = centerZ;
            this.y = y;
            this.similarity = similarity;
        }
    }
}
