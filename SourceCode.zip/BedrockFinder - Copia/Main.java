/*
 * Decompiled with CFR 0.152.
 */
package com.mike;

import com.mike.BedrockBlock;
import com.mike.BedrockFinderGUI;
import com.mike.BedrockReader;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public class Main {
    static ArrayList<BedrockBlock> blocks = new ArrayList();
    static BedrockReader bedrockReader;

    public static void main(String[] args) {
        if (args.length == 0) {
            BedrockFinderGUI.main(args);
            return;
        }
        long seed = Long.parseLong(args[0]);
        BedrockReader.BedrockType bedrockType = switch (args[1]) {
            case "floor" -> BedrockReader.BedrockType.BEDROCK_FLOOR;
            case "roof" -> BedrockReader.BedrockType.BEDROCK_ROOF;
            default -> BedrockReader.BedrockType.BEDROCK_FLOOR;
        };
        Arrays.stream(args).skip(2L).forEach(arg -> {
            BedrockBlock block = new BedrockBlock((String)arg);
            blocks.add(block);
        });
        blocks.sort((b1, b2) -> {
            switch (bedrockType) {
                case BEDROCK_FLOOR: {
                    return b1.y < b2.y ? 1 : -1;
                }
                case BEDROCK_ROOF: {
                    return b1.y < b2.y ? -1 : 1;
                }
            }
            return 0;
        });
        if (blocks.size() == 0) {
            return;
        }
        bedrockReader = new BedrockReader(seed, bedrockType);
        boolean foundPattern = Main.checkFormation(0, 0);
        if (foundPattern) {
            int minX = blocks.stream().mapToInt(b -> b.x).min().orElse(0);
            int maxX = blocks.stream().mapToInt(b -> b.x).max().orElse(0);
            int minZ = blocks.stream().mapToInt(b -> b.z).min().orElse(0);
            int maxZ = blocks.stream().mapToInt(b -> b.z).max().orElse(0);
            int centerX = (minX + maxX) / 2;
            int centerZ = (minZ + maxZ) / 2;
            System.out.println("Found match at X:" + centerX + " Z:" + centerZ);
            System.out.println("Match grid:");
            int y = Main.blocks.get((int)0).y;
            System.out.println(Main.generateGrid(centerX, centerZ, y, ""));
        } else {
            System.out.println("No match found at the specified coordinates.");
        }
    }

    static boolean checkFormation(int x, int z) {
        return Main.checkFormationExact(x, z, blocks);
    }

    static boolean checkFormationExact(int x, int z, List<BedrockBlock> pattern) {
        int matchCount = 0;
        int totalBlocks = pattern.size();
        for (BedrockBlock block : pattern) {
            boolean actualBedrock = bedrockReader.isBedrock(block.x, block.y, block.z);
            if (block.shouldBeBedrock() == actualBedrock) {
                ++matchCount;
                continue;
            }
            return false;
        }
        return matchCount == totalBlocks;
    }

    static String generateGrid(int centerX, int centerZ, int y, String title) {
        StringBuilder grid = new StringBuilder();
        grid.append(title).append("\n");
        int z = centerZ - 8;
        while (z <= centerZ + 7) {
            int x = centerX - 8;
            while (x <= centerX + 7) {
                boolean isBedrock = bedrockReader.isBedrock(x, y, z);
                grid.append(isBedrock ? "1 " : "0 ");
                ++x;
            }
            grid.append("\n");
            ++z;
        }
        return grid.toString();
    }

    static enum Direction {
        LEFT,
        RIGHT,
        UP,
        DOWN;

    }
}
