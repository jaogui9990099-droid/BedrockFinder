package com.mike.extracted;

import java.nio.charset.Charset;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;

public class SimpleHashing {
    
    public static HashFunction md5() {
        return new HashFunction("MD5");
    }
    
    public static HashFunction sha1() {
        return new HashFunction("SHA-1");
    }
    
    public static HashFunction sha256() {
        return new HashFunction("SHA-256");
    }
    
    public static class HashFunction {
        private final String algorithm;
        
        public HashFunction(String algorithm) {
            this.algorithm = algorithm;
        }
        
        public HashCode hashString(String input, Charset charset) {
            try {
                MessageDigest digest = MessageDigest.getInstance(algorithm);
                byte[] hash = digest.digest(input.getBytes(charset));
                return new HashCode(hash);
            } catch (NoSuchAlgorithmException e) {
                throw new RuntimeException("Algorithm not available: " + algorithm, e);
            }
        }
        
        public HashCode hashBytes(byte[] input) {
            try {
                MessageDigest digest = MessageDigest.getInstance(algorithm);
                byte[] hash = digest.digest(input);
                return new HashCode(hash);
            } catch (NoSuchAlgorithmException e) {
                throw new RuntimeException("Algorithm not available: " + algorithm, e);
            }
        }
    }
    
    public static class HashCode {
        private final byte[] bytes;
        
        public HashCode(byte[] bytes) {
            this.bytes = bytes.clone();
        }
        
        public byte[] asBytes() {
            return bytes.clone();
        }
        
        public String toString() {
            StringBuilder sb = new StringBuilder();
            for (byte b : bytes) {
                sb.append(String.format("%02x", b & 0xFF));
            }
            return sb.toString();
        }
    }
}