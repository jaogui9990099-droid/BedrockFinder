package com.mike.extracted;

public class SimpleLongs {
    
    /**
     * Converte 8 bytes em um long
     */
    public static long fromBytes(byte b1, byte b2, byte b3, byte b4, byte b5, byte b6, byte b7, byte b8) {
        return ((long) b1 << 56) |
               ((long) (b2 & 0xFF) << 48) |
               ((long) (b3 & 0xFF) << 40) |
               ((long) (b4 & 0xFF) << 32) |
               ((long) (b5 & 0xFF) << 24) |
               ((long) (b6 & 0xFF) << 16) |
               ((long) (b7 & 0xFF) << 8) |
               ((long) (b8 & 0xFF));
    }
    
    /**
     * Converte um array de bytes em long
     */
    public static long fromByteArray(byte[] bytes) {
        if (bytes.length < 8) {
            throw new IllegalArgumentException("Array must have at least 8 bytes");
        }
        return fromBytes(bytes[0], bytes[1], bytes[2], bytes[3], bytes[4], bytes[5], bytes[6], bytes[7]);
    }
    
    /**
     * Converte um long em array de bytes
     */
    public static byte[] toByteArray(long value) {
        return new byte[] {
            (byte) (value >>> 56),
            (byte) (value >>> 48),
            (byte) (value >>> 40),
            (byte) (value >>> 32),
            (byte) (value >>> 24),
            (byte) (value >>> 16),
            (byte) (value >>> 8),
            (byte) value
        };
    }
}